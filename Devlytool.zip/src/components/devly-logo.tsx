interface DevlyLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl' | 'favicon'
  className?: string
  showText?: boolean
}

export function DevlyLogo({ size = 'md', className = '', showText = true }: DevlyLogoProps) {
  const sizeClasses = {
    sm: 'w-8 h-8',
    md: 'w-10 h-10',
    lg: 'w-16 h-16',
    xl: 'w-20 h-20',
    favicon: 'w-6 h-6'
  }

  const textSizes = {
    sm: 'text-lg',
    md: 'text-xl',
    lg: 'text-3xl',
    xl: 'text-4xl',
    favicon: 'text-xs'
  }

  return (
    <div className={`flex items-center gap-3 ${className}`}>
      {/* Logo Icon */}
      <div className={`relative ${sizeClasses[size]}`}>
        <svg
          viewBox="0 0 40 40"
          className="w-full h-full"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Background circle with gradient */}
          <defs>
            <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#8B5CF6" />
              <stop offset="50%" stopColor="#EC4899" />
              <stop offset="100%" stopColor="#F43F5E" />
            </linearGradient>
            <linearGradient id="textGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#8B5CF6" />
              <stop offset="100%" stopColor="#EC4899" />
            </linearGradient>
          </defs>
          
          {/* Main circle */}
          <circle cx="20" cy="20" r="18" fill="url(#logoGradient)" />
          
          {/* Code brackets */}
          <path
            d="M12 14 L8 20 L12 26"
            stroke="white"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            fill="none"
          />
          <path
            d="M28 14 L32 20 L28 26"
            stroke="white"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            fill="none"
          />
          
          {/* Center dot */}
          <circle cx="20" cy="20" r="2" fill="white" />
          
          {/* Connection lines */}
          <path
            d="M14 20 L18 20 M22 20 L26 20"
            stroke="white"
            strokeWidth="1.5"
            strokeLinecap="round"
          />
        </svg>
      </div>
      
      {/* Logo Text */}
      {showText && (
        <span 
          className={`font-bold ${textSizes[size]} bg-gradient-to-r from-purple-400 via-pink-400 to-red-400 bg-clip-text text-transparent`}
        >
          Devly
        </span>
      )}
    </div>
  )
}