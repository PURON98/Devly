import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "sonner";
import { ThemeProvider } from "@/components/theme-provider";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "DevToolkit AI - Professional Developer Tools",
  description: "Comprehensive suite of 20 professional developer tools including minifier, formatter, encoders, generators, converters, px to rem converter, and clamp function calculator for modern web development.",
  keywords: ["DevToolkit", "developer tools", "minifier", "formatter", "encoder", "generator", "converter", "px to rem", "clamp calculator", "web development", "JSON", "Base64", "QR code"],
  authors: [{ name: "DevToolkit AI" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "DevToolkit AI - Professional Developer Tools",
    description: "20 essential developer tools in one comprehensive suite",
    url: "https://chat.z.ai",
    siteName: "DevToolkit AI",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "DevToolkit AI - Professional Developer Tools",
    description: "20 essential developer tools in one comprehensive suite",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          {children}
          <Toaster />
          <SonnerToaster />
        </ThemeProvider>
      </body>
    </html>
  );
}
