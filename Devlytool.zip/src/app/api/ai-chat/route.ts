import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

export async function POST(request: NextRequest) {
  try {
    const { messages, language, tone } = await request.json()
    
    if (!messages || !Array.isArray(messages)) {
      return NextResponse.json(
        { error: 'Invalid messages format' },
        { status: 400 }
      )
    }

    const zai = await ZAI.create()
    
    // Build system prompt based on language and tone
    let systemPrompt = 'You are a helpful programming assistant. '
    
    if (language && language !== 'auto') {
      systemPrompt += `Please respond primarily in ${language}. `
    }
    
    if (tone) {
      switch (tone) {
        case 'formal':
          systemPrompt += 'Use a formal, professional tone. '
          break
        case 'casual':
          systemPrompt += 'Use a friendly, casual tone. '
          break
        case 'technical':
          systemPrompt += 'Be very technical and detailed in your explanations. '
          break
        case 'educational':
          systemPrompt += 'Explain concepts in an educational, step-by-step manner. '
          break
      }
    }

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: systemPrompt
        },
        ...messages
      ],
      temperature: 0.7,
      max_tokens: 2000
    })

    const response = completion.choices[0]?.message?.content
    
    if (!response) {
      return NextResponse.json(
        { error: 'No response generated' },
        { status: 500 }
      )
    }

    return NextResponse.json({ response })
    
  } catch (error: any) {
    console.error('AI Chat API Error:', error)
    return NextResponse.json(
      { error: error.message || 'Failed to process request' },
      { status: 500 }
    )
  }
}