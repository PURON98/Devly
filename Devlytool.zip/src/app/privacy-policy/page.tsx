'use client'

import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { DevlyLogo } from '@/components/devly-logo'
import { ArrowLeft, Shield, Eye, Database, Lock, UserCheck, Cookie, FileText } from 'lucide-react'
import Link from 'next/link'

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-background">
      <header className="bg-card shadow-lg border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center gap-4">
              <Link href="/">
                <Button variant="outline" className="bg-secondary border-border text-secondary-foreground hover:bg-muted">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Tools
                </Button>
              </Link>
              <DevlyLogo size="md" />
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <div className="flex justify-center items-center gap-3 mb-4">
            <Shield className="h-8 w-8 text-purple-600" />
            <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-red-400 bg-clip-text text-transparent">
              Privacy Policy
            </h1>
          </div>
          <p className="text-lg text-muted-foreground">
            Last updated: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
          </p>
        </div>

        <div className="space-y-8">
          <Card className="border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Eye className="h-5 w-5 text-purple-600" />
                Introduction
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">
                At Devly Tools, accessible from devly.tools, one of our main priorities is the privacy of our visitors. 
                This Privacy Policy document contains types of information that is collected and recorded by Devly Tools 
                and how we use it.
              </p>
              <p className="text-muted-foreground">
                This Privacy Policy applies only to our online activities and is valid for visitors to our website 
                with regards to the information that they shared and/or collect in Devly Tools.
              </p>
            </CardContent>
          </Card>

          <Card className="border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5 text-purple-600" />
                Information We Collect
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">
                We may collect and store the following information:
              </p>
              <ul className="list-disc list-inside space-y-2 text-muted-foreground ml-4">
                <li><strong>Log Data:</strong> Information that your browser sends whenever you visit our Service (IP address, browser type, ISP, date and time, referring/exit pages)</li>
                <li><strong>Cookies and Tracking:</strong> We use cookies to enhance your experience and analyze site traffic</li>
                <li><strong>Usage Data:</strong> Information on how the Service is accessed and used</li>
                <li><strong>Tool Usage:</strong> Data about which tools you use and how you interact with them</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Cookie className="h-5 w-5 text-purple-600" />
                Cookies and Web Beacons
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">
                Devly Tools uses "cookies" to help personalize your online experience. A cookie is a text file 
                that is placed on your hard disk by a web page server. Cookies cannot be used to run programs 
                or deliver viruses to your computer.
              </p>
              <p className="text-muted-foreground">
                You can choose to have your computer warn you each time a cookie is being sent, or you can 
                choose to turn off all cookies. You do this through your browser settings.
              </p>
            </CardContent>
          </Card>

          <Card className="border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lock className="h-5 w-5 text-purple-600" />
                Data Security
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">
                The security of your data is important to us. We implement appropriate technical and organizational 
                measures to protect your personal information against unauthorized access, alteration, disclosure, 
                or destruction.
              </p>
              <p className="text-muted-foreground">
                However, remember that no method of transmission over the Internet or method of electronic storage 
                is 100% secure. While we strive to use commercially acceptable means to protect your personal 
                information, we cannot guarantee its absolute security.
              </p>
            </CardContent>
          </Card>

          <Card className="border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <UserCheck className="h-5 w-5 text-purple-600" />
                Your Data Protection Rights
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">
                You have certain data protection rights. We aim to take reasonable steps to allow you to 
                correct, amend, delete, or limit the use of your Personal Data:
              </p>
              <ul className="list-disc list-inside space-y-2 text-muted-foreground ml-4">
                <li><strong>Access:</strong> Request copies of your personal data</li>
                <li><strong>Correction:</strong> Request correction of any inaccurate personal data</li>
                <li><strong>Deletion:</strong> Request deletion of your personal data</li>
                <li><strong>Restriction:</strong> Request restriction of processing your personal data</li>
                <li><strong>Portability:</strong> Request transfer of your personal data to another service</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-purple-600" />
                Third-Party Services
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">
                Devly Tools may use third-party services that have their own privacy policies:
              </p>
              <ul className="list-disc list-inside space-y-2 text-muted-foreground ml-4">
                <li><strong>Analytics:</strong> We may use analytics services to understand how our Service is used</li>
                <li><strong>Hosting:</strong> Our Service is hosted on reliable third-party infrastructure</li>
                <li><strong>CDN:</strong> We may use CDN services to improve performance globally</li>
              </ul>
              <p className="text-muted-foreground">
                We have no control over and assume no responsibility for the content, privacy policies, 
                or practices of any third-party sites or services.
              </p>
            </CardContent>
          </Card>

          <Card className="border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Eye className="h-5 w-5 text-purple-600" />
                Children's Privacy
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">
                Our Service does not address anyone under the age of 13 ("Children"). We do not knowingly 
                collect personally identifiable information from anyone under the age of 13. If you are a 
                parent or guardian and you are aware that your child has provided us with personal information, 
                please contact us.
              </p>
            </CardContent>
          </Card>

          <Card className="border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-purple-600" />
                Changes to This Privacy Policy
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">
                We may update our Privacy Policy from time to time. We will notify you of any changes by 
                posting the new Privacy Policy on this page and updating the "Last updated" date at the top.
              </p>
              <p className="text-muted-foreground">
                You are advised to review this Privacy Policy periodically for any changes. 
                Changes to this Privacy Policy are effective when they are posted on this page.
              </p>
            </CardContent>
          </Card>

          <Card className="border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-purple-600" />
                Contact Us
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">
                If you have any questions about this Privacy Policy, please contact us through our platform.
              </p>
              <p className="text-muted-foreground">
                This privacy policy is effective as of {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}.
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="mt-12 text-center">
          <Link href="/">
            <Button className="bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 text-white">
              Back to Devly Tools
            </Button>
          </Link>
        </div>
      </main>

      <footer className="bg-card border-t border-border mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="text-center text-sm text-muted-foreground">
            <p className="mb-2">© 2024 Devly. Professional utilities for modern development.</p>
            <div className="flex justify-center items-center gap-4 text-xs">
              <Link href="/terms-of-use" className="text-purple-600 hover:text-purple-700 underline">
                Terms of Use
              </Link>
              <span className="text-muted-foreground">•</span>
              <Link href="/privacy-policy" className="text-purple-600 hover:text-purple-700 underline">
                Privacy Policy
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}