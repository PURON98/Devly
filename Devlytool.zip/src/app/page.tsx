'use client'

import React, { useState, useMemo } from 'react'
import Link from 'next/link'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { ThemeToggle } from '@/components/theme-toggle'
import { DevlyLogo } from '@/components/devly-logo'
import { 
  Copy, Check, Download, Upload, RefreshCw, Eye, EyeOff, Search, 
  Code, FileJson, Lock, Link as LinkIcon, Palette, Type, QrCode, Key, FileText,
  GitBranch, Clock, Ruler, Calculator, Hash, Fingerprint, ImageIcon, Sparkles,
  Minimize2, Maximize2, ArrowRight, Star, Send, Settings, Zap
} from 'lucide-react'
import { toast } from 'sonner'


interface ToolProps {
  title: string
  description: string
  category: string
  icon: React.ReactNode
  children: React.ReactNode
}

// Tool Grid Card Component
function ToolGridCard({ tool, index, onOpen, isFavorite, onToggleFavorite }: { 
  tool: any, 
  index: number, 
  onOpen: () => void,
  isFavorite: boolean,
  onToggleFavorite: () => void
}) {
  return (
    <Card className="group cursor-pointer transition-all duration-200 hover:scale-[1.02] hover:shadow-xl bg-card border-border hover:border-purple-600 relative">
      <CardContent className="p-6" onClick={onOpen}>
        <div className="flex items-start gap-4">
          <div className="flex-shrink-0 w-8 h-8 bg-gradient-to-br from-purple-500 to-pink-600 rounded-lg flex items-center justify-center text-white text-sm font-bold">
            {index + 1}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-2">
              <div className="p-2 bg-gradient-to-br from-purple-500 to-pink-600 rounded-lg text-white">
                {tool.icon}
              </div>
              <Badge variant="secondary" className="text-xs bg-muted text-muted-foreground border-border">
                {tool.category}
              </Badge>
            </div>
            <h3 className="text-lg font-semibold text-card-foreground mb-1 group-hover:text-purple-400 transition-colors">
              {tool.name}
            </h3>
            <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
              {tool.description}
            </p>
            <div className="flex gap-2">
              <Button 
                className="flex-1 bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 text-white font-medium py-2"
              >
                Open Tool →
              </Button>
              <Button
                onClick={(e) => {
                  e.stopPropagation()
                  onToggleFavorite()
                }}
                variant="outline"
                className="px-3 py-2 bg-secondary border-border text-secondary-foreground hover:bg-muted"
              >
                <Star className={`h-4 w-4 ${isFavorite ? 'fill-yellow-400 text-yellow-400' : ''}`} />
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function ToolCard({ title, description, category, icon, children }: ToolProps) {
  return (
    <Card className="w-full border-0 shadow-lg bg-card border-border">
      <CardHeader className="pb-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-gradient-to-br from-purple-500 to-pink-600 rounded-lg text-white">
            {icon}
          </div>
          <div className="flex-1">
            <CardTitle className="text-xl font-bold text-card-foreground">{title}</CardTitle>
            <CardDescription className="text-sm text-muted-foreground">{description}</CardDescription>
          </div>
          <Badge variant="secondary" className="text-xs bg-muted text-muted-foreground border-border">
            {category}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        {children}
      </CardContent>
    </Card>
  )
}

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false)
  
  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(text)
      setCopied(true)
      toast.success('Copied to clipboard!')
      setTimeout(() => setCopied(false), 2000)
    } catch (err) {
      toast.error('Failed to copy')
    }
  }
  
  return (
    <Button
      variant="outline"
      size="sm"
      onClick={handleCopy}
      className="flex items-center gap-2 hover:bg-purple-50 hover:border-purple-200 hover:text-purple-700 transition-colors bg-secondary border-border text-secondary-foreground"
    >
      {copied ? <Check className="h-4 w-4 text-green-400" /> : <Copy className="h-4 w-4" />}
      {copied ? 'Copied!' : 'Copy'}
    </Button>
  )
}

// HTML/CSS/JS Minifier
function MinifierTool() {
  const [input, setInput] = useState('')
  const [output, setOutput] = useState('')
  const [type, setType] = useState('html')
  
  const minify = () => {
    try {
      let minified = input
        .replace(/\/\*[\s\S]*?\*\//g, '')
        .replace(/\/\/.*$/gm, '')
        .replace(/\s+/g, ' ')
        .replace(/>\s+</g, '><')
        .replace(/\s*([{}();,])\s*/g, '$1')
        .trim()
      
      setOutput(minified)
      toast.success('Code minified successfully!')
    } catch (error) {
      toast.error('Failed to minify code')
    }
  }
  
  return (
    <div className="space-y-6">
      <Select value={type} onValueChange={setType}>
        <SelectTrigger className="w-full bg-input border-border text-foreground">
          <SelectValue />
        </SelectTrigger>
        <SelectContent className="bg-popover border-border">
          <SelectItem value="html" className="text-foreground">HTML</SelectItem>
          <SelectItem value="css" className="text-foreground">CSS</SelectItem>
          <SelectItem value="js" className="text-foreground">JavaScript</SelectItem>
        </SelectContent>
      </Select>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="input" className="text-sm font-medium text-foreground">Input Code</Label>
          <Textarea
            id="input"
            placeholder={`Enter your ${type.toUpperCase()} code...`}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            className="min-h-[250px] font-mono text-sm border-2 focus:border-purple-400 bg-input border-border text-foreground placeholder-muted-foreground"
          />
        </div>
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <Label htmlFor="output" className="text-sm font-medium text-foreground">Minified Output</Label>
            {output && <CopyButton text={output} />}
          </div>
          <Textarea
            id="output"
            placeholder="Minified code will appear here..."
            value={output}
            readOnly
            className="min-h-[250px] font-mono text-sm border-2 bg-muted border-border text-foreground"
          />
        </div>
      </div>
      
      <Button onClick={minify} className="w-full bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 text-white font-medium py-3">
        <Minimize2 className="h-4 w-4 mr-2" />
        Minify Code
      </Button>
    </div>
  )
}

// JSON Formatter
function JSONFormatterTool() {
  const [input, setInput] = useState('')
  const [output, setOutput] = useState('')
  const [error, setError] = useState('')
  
  const format = () => {
    try {
      const parsed = JSON.parse(input)
      const formatted = JSON.stringify(parsed, null, 2)
      setOutput(formatted)
      setError('')
      toast.success('JSON formatted successfully!')
    } catch (err) {
      setError('Invalid JSON: ' + (err as Error).message)
      toast.error('Invalid JSON format')
    }
  }
  
  const minify = () => {
    try {
      const parsed = JSON.parse(input)
      const minified = JSON.stringify(parsed)
      setOutput(minified)
      setError('')
      toast.success('JSON minified successfully!')
    } catch (err) {
      setError('Invalid JSON: ' + (err as Error).message)
      toast.error('Invalid JSON format')
    }
  }
  
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="input" className="text-sm font-medium text-foreground">Input JSON</Label>
          <Textarea
            id="input"
            placeholder="Enter JSON to format..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            className="min-h-[250px] font-mono text-sm border-2 focus:border-purple-400 bg-input border-border text-foreground placeholder-muted-foreground"
          />
        </div>
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <Label htmlFor="output" className="text-sm font-medium text-foreground">Formatted JSON</Label>
            {output && <CopyButton text={output} />}
          </div>
          <Textarea
            id="output"
            placeholder="Formatted JSON will appear here..."
            value={output}
            readOnly
            className="min-h-[250px] font-mono text-sm border-2 bg-muted border-border text-foreground"
          />
          {error && <p className="text-destructive text-sm mt-2">{error}</p>}
        </div>
      </div>
      
      <div className="flex gap-3">
        <Button onClick={format} className="flex-1 bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 text-white font-medium py-3">
          <Maximize2 className="h-4 w-4 mr-2" />
          Format JSON
        </Button>
        <Button onClick={minify} variant="outline" className="flex-1 font-medium py-3 bg-secondary border-border text-secondary-foreground hover:bg-muted">
          <Minimize2 className="h-4 w-4 mr-2" />
          Minify JSON
        </Button>
      </div>
    </div>
  )
}

// Base64 Encoder/Decoder
function Base64Tool() {
  const [input, setInput] = useState('')
  const [output, setOutput] = useState('')
  const [mode, setMode] = useState<'encode' | 'decode'>('encode')
  
  const process = () => {
    try {
      if (mode === 'encode') {
        const encoded = btoa(input)
        setOutput(encoded)
        toast.success('Text encoded successfully!')
      } else {
        const decoded = atob(input)
        setOutput(decoded)
        toast.success('Text decoded successfully!')
      }
    } catch (error) {
      toast.error('Failed to process text')
    }
  }
  
  return (
    <div className="space-y-6">
      <Tabs value={mode} onValueChange={(v) => setMode(v as 'encode' | 'decode')} className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="encode" className="font-medium">Encode</TabsTrigger>
          <TabsTrigger value="decode" className="font-medium">Decode</TabsTrigger>
        </TabsList>
      </Tabs>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="input" className="text-sm font-medium">
            {mode === 'encode' ? 'Plain Text' : 'Base64 Text'}
          </Label>
          <Textarea
            id="input"
            placeholder={mode === 'encode' ? 'Enter text to encode...' : 'Enter Base64 to decode...'}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            className="min-h-[250px] border-2 focus:border-purple-400 bg-input border-border text-foreground placeholder-muted-foreground"
          />
        </div>
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <Label htmlFor="output" className="text-sm font-medium">
              {mode === 'encode' ? 'Base64 Output' : 'Decoded Text'}
            </Label>
            {output && <CopyButton text={output} />}
          </div>
          <Textarea
            id="output"
            placeholder={mode === 'encode' ? 'Base64 will appear here...' : 'Decoded text will appear here...'}
            value={output}
            readOnly
            className="min-h-[250px] border-2 bg-muted border-border text-foreground"
          />
        </div>
      </div>
      
      <Button onClick={process} className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-medium py-3">
        <Lock className="h-4 w-4 mr-2" />
        {mode === 'encode' ? 'Encode to Base64' : 'Decode from Base64'}
      </Button>
    </div>
  )
}

// URL Encoder/Decoder
function URLTool() {
  const [input, setInput] = useState('')
  const [output, setOutput] = useState('')
  const [mode, setMode] = useState<'encode' | 'decode'>('encode')
  
  const process = () => {
    try {
      if (mode === 'encode') {
        const encoded = encodeURIComponent(input)
        setOutput(encoded)
        toast.success('URL encoded successfully!')
      } else {
        const decoded = decodeURIComponent(input)
        setOutput(decoded)
        toast.success('URL decoded successfully!')
      }
    } catch (error) {
      toast.error('Failed to process URL')
    }
  }
  
  return (
    <div className="space-y-6">
      <Tabs value={mode} onValueChange={(v) => setMode(v as 'encode' | 'decode')} className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="encode" className="font-medium">Encode</TabsTrigger>
          <TabsTrigger value="decode" className="font-medium">Decode</TabsTrigger>
        </TabsList>
      </Tabs>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="input" className="text-sm font-medium">
            {mode === 'encode' ? 'Original URL' : 'Encoded URL'}
          </Label>
          <Textarea
            id="input"
            placeholder={mode === 'encode' ? 'Enter URL to encode...' : 'Enter encoded URL to decode...'}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            className="min-h-[250px] border-2 focus:border-purple-400 bg-input border-border text-foreground placeholder-muted-foreground"
          />
        </div>
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <Label htmlFor="output" className="text-sm font-medium">
              {mode === 'encode' ? 'Encoded URL' : 'Decoded URL'}
            </Label>
            {output && <CopyButton text={output} />}
          </div>
          <Textarea
            id="output"
            placeholder={mode === 'encode' ? 'Encoded URL will appear here...' : 'Decoded URL will appear here...'}
            value={output}
            readOnly
            className="min-h-[250px] border-2 bg-muted border-border text-foreground"
          />
        </div>
      </div>
      
      <Button onClick={process} className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-medium py-3">
        <LinkIcon className="h-4 w-4 mr-2" />
        {mode === 'encode' ? 'Encode URL' : 'Decode URL'}
      </Button>
    </div>
  )
}

// Color Palette Generator
function ColorPaletteTool() {
  const [baseColor, setBaseColor] = useState('#3B82F6')
  const [palette, setPalette] = useState<string[]>([])
  
  const generatePalette = () => {
    const colors = []
    const hex = baseColor.replace('#', '')
    const r = parseInt(hex.substr(0, 2), 16)
    const g = parseInt(hex.substr(2, 2), 16)
    const b = parseInt(hex.substr(4, 2), 16)
    
    for (let i = 1; i <= 5; i++) {
      const factor = i * 0.2
      colors.push(`rgb(${Math.min(255, r + (255 - r) * factor)}, ${Math.min(255, g + (255 - g) * factor)}, ${Math.min(255, b + (255 - b) * factor)})`)
    }
    colors.push(baseColor)
    for (let i = 1; i <= 5; i++) {
      const factor = i * 0.2
      colors.push(`rgb(${Math.max(0, r - r * factor)}, ${Math.max(0, g - g * factor)}, ${Math.max(0, b - b * factor)})`)
    }
    
    setPalette(colors)
    toast.success('Color palette generated!')
  }
  
  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Label htmlFor="color" className="text-sm font-medium">Base Color</Label>
        <Input
          id="color"
          type="color"
          value={baseColor}
          onChange={(e) => setBaseColor(e.target.value)}
          className="w-20 h-10 border-2"
        />
        <Input
          value={baseColor}
          onChange={(e) => setBaseColor(e.target.value)}
          placeholder="#3B82F6"
          className="flex-1 border-2 focus:border-blue-400"
        />
      </div>
      
      <Button onClick={generatePalette} className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-medium py-3">
        <Palette className="h-4 w-4 mr-2" />
        Generate Palette
      </Button>
      
      {palette.length > 0 && (
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {palette.map((color, index) => (
            <div key={index} className="text-center space-y-2">
              <div
                className="w-full h-20 rounded-xl border-2 border-gray-200 shadow-sm hover:shadow-md transition-shadow"
                style={{ backgroundColor: color }}
              />
              <p className="text-xs font-mono font-medium">{color}</p>
              <CopyButton text={color} />
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

// Lorem Ipsum Generator
function LoremIpsumTool() {
  const [paragraphs, setParagraphs] = useState(3)
  const [words, setWords] = useState(50)
  const [output, setOutput] = useState('')
  const [type, setType] = useState<'paragraphs' | 'words' | 'sentences'>('paragraphs')
  
  const loremWords = [
    'lorem', 'ipsum', 'dolor', 'sit', 'amet', 'consectetur', 'adipiscing', 'elit',
    'sed', 'do', 'eiusmod', 'tempor', 'incididunt', 'ut', 'labore', 'et', 'dolore',
    'magna', 'aliqua', 'enim', 'ad', 'minim', 'veniam', 'quis', 'nostrud',
    'exercitation', 'ullamco', 'laboris', 'nisi', 'aliquip', 'ex', 'ea', 'commodo'
  ]
  
  const generate = () => {
    let result = ''
    
    if (type === 'paragraphs') {
      for (let p = 0; p < paragraphs; p++) {
        let paragraph = ''
        for (let w = 0; w < words; w++) {
          paragraph += loremWords[Math.floor(Math.random() * loremWords.length)]
          if (w < words - 1) paragraph += ' '
          if (w > 0 && w % 10 === 0) paragraph += '. '
        }
        result += paragraph + '.\n\n'
      }
    } else if (type === 'words') {
      for (let w = 0; w < words; w++) {
        result += loremWords[Math.floor(Math.random() * loremWords.length)]
        if (w < words - 1) result += ' '
      }
    } else {
      const sentences = Math.ceil(words / 10)
      for (let s = 0; s < sentences; s++) {
        let sentence = ''
        const sentenceLength = Math.floor(Math.random() * 10) + 5
        for (let w = 0; w < sentenceLength; w++) {
          sentence += loremWords[Math.floor(Math.random() * loremWords.length)]
          if (w < sentenceLength - 1) sentence += ' '
        }
        result += sentence.charAt(0).toUpperCase() + sentence.slice(1) + '. '
      }
    }
    
    setOutput(result.trim())
    toast.success('Lorem ipsum generated!')
  }
  
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="space-y-2">
          <Label htmlFor="type" className="text-sm font-medium">Type</Label>
          <Select value={type} onValueChange={(v) => setType(v as any)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="paragraphs">Paragraphs</SelectItem>
              <SelectItem value="words">Words</SelectItem>
              <SelectItem value="sentences">Sentences</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        {type === 'paragraphs' && (
          <div className="space-y-2">
            <Label htmlFor="paragraphs" className="text-sm font-medium">Paragraphs</Label>
            <Input
              id="paragraphs"
              type="number"
              value={paragraphs}
              onChange={(e) => setParagraphs(parseInt(e.target.value) || 1)}
              min="1"
              max="20"
              className="border-2 focus:border-blue-400"
            />
          </div>
        )}
        
        <div className="space-y-2">
          <Label htmlFor="words" className="text-sm font-medium">
            {type === 'paragraphs' ? 'Words per Paragraph' : type === 'words' ? 'Total Words' : 'Words per Sentence'}
          </Label>
          <Input
            id="words"
            type="number"
            value={words}
            onChange={(e) => setWords(parseInt(e.target.value) || 10)}
            min="10"
            max="200"
            className="border-2 focus:border-blue-400"
          />
        </div>
      </div>
      
      <Button onClick={generate} className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-medium py-3">
        <Type className="h-4 w-4 mr-2" />
        Generate Lorem Ipsum
      </Button>
      
      {output && (
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <Label className="text-sm font-medium">Generated Text</Label>
            <CopyButton text={output} />
          </div>
          <Textarea
            value={output}
            readOnly
            className="min-h-[250px] border-2 bg-muted border-border text-foreground"
          />
        </div>
      )}
    </div>
  )
}

// QR Code Generator
function QRCodeTool() {
  const [text, setText] = useState('')
  const [size, setSize] = useState(200)
  const [qrCode, setQrCode] = useState('')
  
  const generate = () => {
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encodeURIComponent(text)}`
    setQrCode(qrUrl)
    toast.success('QR code generated!')
  }
  
  const download = () => {
    if (qrCode) {
      const link = document.createElement('a')
      link.href = qrCode
      link.download = 'qrcode.png'
      link.click()
      toast.success('QR code downloaded!')
    }
  }
  
  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="text" className="text-sm font-medium">Text or URL</Label>
        <Textarea
          id="text"
          placeholder="Enter text or URL to generate QR code..."
          value={text}
          onChange={(e) => setText(e.target.value)}
          className="min-h-[100px] border-2 focus:border-blue-400"
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="size" className="text-sm font-medium">Size (pixels)</Label>
        <Input
          id="size"
          type="number"
          value={size}
          onChange={(e) => setSize(parseInt(e.target.value) || 200)}
          min="100"
          max="500"
          className="border-2 focus:border-blue-400"
        />
      </div>
      
      <Button onClick={generate} className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-medium py-3">
        <QrCode className="h-4 w-4 mr-2" />
        Generate QR Code
      </Button>
      
      {qrCode && (
        <div className="text-center space-y-4">
          <div className="inline-block p-4 bg-white rounded-xl shadow-lg border-2 border-gray-200">
            <img src={qrCode} alt="Generated QR Code" className="rounded-lg" />
          </div>
          <Button onClick={download} variant="outline" className="font-medium py-3">
            <Download className="h-4 w-4 mr-2" />
            Download QR Code
          </Button>
        </div>
      )}
    </div>
  )
}

// Password Generator
function PasswordGeneratorTool() {
  const [length, setLength] = useState(16)
  const [includeUppercase, setIncludeUppercase] = useState(true)
  const [includeLowercase, setIncludeLowercase] = useState(true)
  const [includeNumbers, setIncludeNumbers] = useState(true)
  const [includeSymbols, setIncludeSymbols] = useState(true)
  const [password, setPassword] = useState('')
  
  const generate = () => {
    let charset = ''
    if (includeUppercase) charset += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    if (includeLowercase) charset += 'abcdefghijklmnopqrstuvwxyz'
    if (includeNumbers) charset += '0123456789'
    if (includeSymbols) charset += '!@#$%^&*()_+-=[]{}|;:,.<>?'
    
    if (!charset) {
      toast.error('Please select at least one character type')
      return
    }
    
    let result = ''
    for (let i = 0; i < length; i++) {
      result += charset.charAt(Math.floor(Math.random() * charset.length))
    }
    
    setPassword(result)
    toast.success('Password generated!')
  }
  
  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="length" className="text-sm font-medium">Password Length: {length}</Label>
        <Input
          id="length"
          type="range"
          min="4"
          max="64"
          value={length}
          onChange={(e) => setLength(parseInt(e.target.value))}
          className="w-full"
        />
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div className="flex items-center space-x-2">
          <input
            type="checkbox"
            id="uppercase"
            checked={includeUppercase}
            onChange={(e) => setIncludeUppercase(e.target.checked)}
            className="w-4 h-4"
          />
          <Label htmlFor="uppercase" className="text-sm font-medium">Uppercase (A-Z)</Label>
        </div>
        <div className="flex items-center space-x-2">
          <input
            type="checkbox"
            id="lowercase"
            checked={includeLowercase}
            onChange={(e) => setIncludeLowercase(e.target.checked)}
            className="w-4 h-4"
          />
          <Label htmlFor="lowercase" className="text-sm font-medium">Lowercase (a-z)</Label>
        </div>
        <div className="flex items-center space-x-2">
          <input
            type="checkbox"
            id="numbers"
            checked={includeNumbers}
            onChange={(e) => setIncludeNumbers(e.target.checked)}
            className="w-4 h-4"
          />
          <Label htmlFor="numbers" className="text-sm font-medium">Numbers (0-9)</Label>
        </div>
        <div className="flex items-center space-x-2">
          <input
            type="checkbox"
            id="symbols"
            checked={includeSymbols}
            onChange={(e) => setIncludeSymbols(e.target.checked)}
            className="w-4 h-4"
          />
          <Label htmlFor="symbols" className="text-sm font-medium">Symbols (!@#$...)</Label>
        </div>
      </div>
      
      <Button onClick={generate} className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-medium py-3">
        <Key className="h-4 w-4 mr-2" />
        Generate Password
      </Button>
      
      {password && (
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <Label className="text-sm font-medium">Generated Password</Label>
            <CopyButton text={password} />
          </div>
          <Input
            value={password}
            readOnly
            className="font-mono text-lg border-2 bg-gray-50"
          />
        </div>
      )}
    </div>
  )
}

// Markdown Preview
function MarkdownTool() {
  const [markdown, setMarkdown] = useState('')
  const [preview, setPreview] = useState('')
  
  const convert = () => {
    let html = markdown
      .replace(/^### (.*$)/gim, '<h3>$1</h3>')
      .replace(/^## (.*$)/gim, '<h2>$1</h2>')
      .replace(/^# (.*$)/gim, '<h1>$1</h1>')
      .replace(/\*\*(.*)\*\*/gim, '<strong>$1</strong>')
      .replace(/\*(.*)\*/gim, '<em>$1</em>')
      .replace(/\[([^\]]+)\]\(([^)]+)\)/gim, '<a href="$2">$1</a>')
      .replace(/`([^`]+)`/gim, '<code>$1</code>')
      .replace(/^\- (.*$)/gim, '<li>$1</li>')
      .replace(/(<li>.*<\/li>)/s, '<ul>$1</ul>')
      .replace(/\n/gim, '<br>')
    
    setPreview(html)
    toast.success('Markdown converted!')
  }
  
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="markdown" className="text-sm font-medium">Markdown</Label>
          <Textarea
            id="markdown"
            placeholder="Enter markdown text..."
            value={markdown}
            onChange={(e) => setMarkdown(e.target.value)}
            className="min-h-[300px] border-2 focus:border-blue-400"
          />
        </div>
        <div className="space-y-2">
          <Label className="text-sm font-medium">Preview</Label>
          <div
            className="border-2 border-gray-200 rounded-lg p-4 min-h-[300px] prose prose-sm max-w-none bg-white"
            dangerouslySetInnerHTML={{ __html: preview }}
          />
        </div>
      </div>
      
      <Button onClick={convert} className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-medium py-3">
        <FileText className="h-4 w-4 mr-2" />
        Convert Markdown
      </Button>
    </div>
  )
}

// Regex Tester
function RegexTool() {
  const [pattern, setPattern] = useState('')
  const [flags, setFlags] = useState('g')
  const [testString, setTestString] = useState('')
  const [matches, setMatches] = useState<string[]>([])
  const [error, setError] = useState('')
  
  const test = () => {
    try {
      const regex = new RegExp(pattern, flags)
      const found = testString.match(regex)
      setMatches(found || [])
      setError('')
      toast.success(`Found ${found ? found.length : 0} matches!`)
    } catch (err) {
      setError('Invalid regex pattern')
      toast.error('Invalid regex pattern')
    }
  }
  
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="pattern" className="text-sm font-medium">Regex Pattern</Label>
          <Input
            id="pattern"
            placeholder="Enter regex pattern..."
            value={pattern}
            onChange={(e) => setPattern(e.target.value)}
            className="font-mono border-2 focus:border-blue-400"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="flags" className="text-sm font-medium">Flags</Label>
          <Input
            id="flags"
            placeholder="g, i, m, etc."
            value={flags}
            onChange={(e) => setFlags(e.target.value)}
            className="font-mono border-2 focus:border-blue-400"
          />
        </div>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="testString" className="text-sm font-medium">Test String</Label>
        <Textarea
          id="testString"
          placeholder="Enter text to test against..."
          value={testString}
          onChange={(e) => setTestString(e.target.value)}
          className="min-h-[100px] border-2 focus:border-blue-400"
        />
      </div>
      
      <Button onClick={test} className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-medium py-3">
        <GitBranch className="h-4 w-4 mr-2" />
        Test Regex
      </Button>
      
      {error && <p className="text-red-500 text-sm">{error}</p>}
      
      {matches.length > 0 && (
        <div className="space-y-2">
          <Label className="text-sm font-medium">Matches ({matches.length})</Label>
          <div className="space-y-2 max-h-40 overflow-y-auto">
            {matches.map((match, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-green-50 border border-green-200 rounded-lg">
                <code className="text-sm">{match}</code>
                <CopyButton text={match} />
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

// Timestamp Converter
function TimestampTool() {
  const [timestamp, setTimestamp] = useState('')
  const [date, setDate] = useState('')
  const [currentTime, setCurrentTime] = useState('')
  
  const convertToDate = () => {
    try {
      const ts = parseInt(timestamp)
      const d = new Date(ts * 1000)
      setDate(d.toISOString())
      toast.success('Timestamp converted!')
    } catch (error) {
      toast.error('Invalid timestamp')
    }
  }
  
  const convertToTimestamp = () => {
    try {
      const d = new Date(date)
      const ts = Math.floor(d.getTime() / 1000)
      setTimestamp(ts.toString())
      toast.success('Date converted!')
    } catch (error) {
      toast.error('Invalid date')
    }
  }
  
  const getCurrentTime = () => {
    const now = Date.now()
    setCurrentTime(now.toString())
    setTimestamp(Math.floor(now / 1000).toString())
    setDate(new Date().toISOString())
  }
  
  return (
    <div className="space-y-6">
      <Button onClick={getCurrentTime} variant="outline" className="w-full font-medium py-3">
        <Clock className="h-4 w-4 mr-2" />
        Get Current Time
      </Button>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="timestamp" className="text-sm font-medium">Unix Timestamp</Label>
          <Input
            id="timestamp"
            placeholder="Enter timestamp..."
            value={timestamp}
            onChange={(e) => setTimestamp(e.target.value)}
            className="border-2 focus:border-blue-400"
          />
          <Button onClick={convertToDate} className="w-full font-medium py-3">
            <ArrowRight className="h-4 w-4 mr-2" />
            Convert to Date
          </Button>
        </div>
        <div className="space-y-2">
          <Label htmlFor="date" className="text-sm font-medium">Date/Time</Label>
          <Input
            id="date"
            type="datetime-local"
            value={date ? new Date(date).toISOString().slice(0, 16) : ''}
            onChange={(e) => setDate(e.target.value)}
            className="border-2 focus:border-blue-400"
          />
          <Button onClick={convertToTimestamp} className="w-full font-medium py-3">
            <ArrowRight className="h-4 w-4 mr-2" />
            Convert to Timestamp
          </Button>
        </div>
      </div>
      
      {currentTime && (
        <div className="text-center p-6 bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl border-2 border-blue-200">
          <p className="text-sm text-muted-foreground font-medium mb-2">Current Time</p>
          <p className="font-mono text-lg">{currentTime} (ms)</p>
          <p className="font-mono text-lg">{Math.floor(parseInt(currentTime) / 1000)} (s)</p>
        </div>
      )}
    </div>
  )
}

// CSS Unit Converter
function CSSUnitTool() {
  const [value, setValue] = useState('')
  const [fromUnit, setFromUnit] = useState('px')
  const [toUnit, setToUnit] = useState('rem')
  const [result, setResult] = useState('')
  
  const convert = () => {
    const num = parseFloat(value)
    if (isNaN(num)) {
      toast.error('Invalid value')
      return
    }
    
    let px = num
    
    if (fromUnit === 'rem') px = num * 16
    else if (fromUnit === 'em') px = num * 16
    else if (fromUnit === 'pt') px = num * 1.333
    else if (fromUnit === 'pc') px = num * 16
    else if (fromUnit === 'in') px = num * 96
    else if (fromUnit === 'cm') px = num * 37.795
    else if (fromUnit === 'mm') px = num * 3.795
    else if (fromUnit === 'vw') px = num * 19.2
    else if (fromUnit === 'vh') px = num * 10.8
    
    let converted = px
    if (toUnit === 'px') converted = px
    else if (toUnit === 'rem') converted = px / 16
    else if (toUnit === 'em') converted = px / 16
    else if (toUnit === 'pt') converted = px / 1.333
    else if (toUnit === 'pc') converted = px / 16
    else if (toUnit === 'in') converted = px / 96
    else if (toUnit === 'cm') converted = px / 37.795
    else if (toUnit === 'mm') converted = px / 3.795
    else if (toUnit === 'vw') converted = px / 19.2
    else if (toUnit === 'vh') converted = px / 10.8
    
    setResult(`${converted.toFixed(4)}${toUnit}`)
    toast.success('Units converted!')
  }
  
  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="value" className="text-sm font-medium">Value</Label>
        <Input
          id="value"
          placeholder="Enter value..."
          value={value}
          onChange={(e) => setValue(e.target.value)}
          className="border-2 focus:border-blue-400"
        />
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="from" className="text-sm font-medium">From</Label>
          <Select value={fromUnit} onValueChange={setFromUnit}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="px">px</SelectItem>
              <SelectItem value="rem">rem</SelectItem>
              <SelectItem value="em">em</SelectItem>
              <SelectItem value="pt">pt</SelectItem>
              <SelectItem value="pc">pc</SelectItem>
              <SelectItem value="in">in</SelectItem>
              <SelectItem value="cm">cm</SelectItem>
              <SelectItem value="mm">mm</SelectItem>
              <SelectItem value="vw">vw</SelectItem>
              <SelectItem value="vh">vh</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="to" className="text-sm font-medium">To</Label>
          <Select value={toUnit} onValueChange={setToUnit}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="px">px</SelectItem>
              <SelectItem value="rem">rem</SelectItem>
              <SelectItem value="em">em</SelectItem>
              <SelectItem value="pt">pt</SelectItem>
              <SelectItem value="pc">pc</SelectItem>
              <SelectItem value="in">in</SelectItem>
              <SelectItem value="cm">cm</SelectItem>
              <SelectItem value="mm">mm</SelectItem>
              <SelectItem value="vw">vw</SelectItem>
              <SelectItem value="vh">vh</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      <Button onClick={convert} className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-medium py-3">
        <Ruler className="h-4 w-4 mr-2" />
        Convert Units
      </Button>
      
      {result && (
        <div className="text-center p-6 bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl border-2 border-green-200">
          <p className="text-sm text-muted-foreground font-medium mb-2">Result</p>
          <p className="text-3xl font-bold text-green-700">{result}</p>
          <CopyButton text={result} />
        </div>
      )}
    </div>
  )
}

// px to rem Converter
function PxToRemTool() {
  const [pxValue, setPxValue] = useState('')
  const [remValue, setRemValue] = useState('')
  const [baseFontSize, setBaseFontSize] = useState(16)
  const [conversionHistory, setConversionHistory] = useState<Array<{px: string, rem: string, timestamp: number}>>([])
  const [batchInput, setBatchInput] = useState('')
  const [batchResults, setBatchResults] = useState<Array<{original: string, converted: string}>>([])
  
  const convertPxToRem = () => {
    const px = parseFloat(pxValue)
    if (isNaN(px)) {
      toast.error('Invalid px value')
      return
    }
    
    const rem = px / baseFontSize
    setRemValue(rem.toFixed(4))
    
    const newConversion = { px: pxValue, rem: rem.toFixed(4), timestamp: Date.now() }
    setConversionHistory(prev => [newConversion, ...prev.slice(0, 9)])
    toast.success('Converted px to rem!')
  }
  
  const convertRemToPx = () => {
    const rem = parseFloat(remValue)
    if (isNaN(rem)) {
      toast.error('Invalid rem value')
      return
    }
    
    const px = rem * baseFontSize
    setPxValue(px.toFixed(2))
    
    const newConversion = { px: px.toFixed(2), rem: remValue, timestamp: Date.now() }
    setConversionHistory(prev => [newConversion, ...prev.slice(0, 9)])
    toast.success('Converted rem to px!')
  }
  
  const processBatch = () => {
    if (!batchInput.trim()) {
      toast.error('Please enter values to convert')
      return
    }
    
    const values = batchInput.split(/[\s,\n]+/).filter(v => v.trim())
    const results = values.map(value => {
      const cleanValue = value.replace(/[^\d.]/g, '')
      const num = parseFloat(cleanValue)
      if (isNaN(num)) return { original: value, converted: 'Invalid' }
      
      if (value.toLowerCase().includes('px')) {
        const rem = num / baseFontSize
        return { original: value, converted: `${rem.toFixed(4)}rem` }
      } else if (value.toLowerCase().includes('rem')) {
        const px = num * baseFontSize
        return { original: value, converted: `${px.toFixed(2)}px` }
      } else {
        // Assume px if no unit specified
        const rem = num / baseFontSize
        return { original: value, converted: `${rem.toFixed(4)}rem` }
      }
    })
    
    setBatchResults(results)
    toast.success(`Processed ${results.length} values!`)
  }
  
  const clearHistory = () => {
    setConversionHistory([])
    toast.success('History cleared!')
  }
  
  const copyAllResults = () => {
    const allResults = batchResults.map(r => `${r.original} = ${r.converted}`).join('\n')
    navigator.clipboard.writeText(allResults)
    toast.success('All results copied!')
  }
  
  return (
    <div className="space-y-6">
      {/* Base Font Size Settings */}
      <div className="p-4 bg-card rounded-lg border-border">
        <div className="flex items-center justify-between mb-3">
          <Label className="text-sm font-medium text-foreground">Base Font Size: {baseFontSize}px</Label>
          <div className="flex gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={() => setBaseFontSize(16)}
              className="bg-muted border-border text-muted-foreground hover:bg-muted"
            >
              Reset
            </Button>
          </div>
        </div>
        <Input
          type="range"
          min="10"
          max="24"
          value={baseFontSize}
          onChange={(e) => setBaseFontSize(parseInt(e.target.value))}
          className="w-full accent-purple-500"
        />
        <div className="flex justify-between text-xs text-muted-foreground mt-1">
          <span>10px</span>
          <span>16px</span>
          <span>24px</span>
        </div>
      </div>
      
      {/* Quick Conversion */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-3">
          <Label htmlFor="pxValue" className="text-sm font-medium text-muted-foreground">Pixels (px)</Label>
          <div className="relative">
            <Input
              id="pxValue"
              placeholder="Enter px value..."
              value={pxValue}
              onChange={(e) => setPxValue(e.target.value)}
              className="border-2 focus:border-purple-400 bg-input border-border text-foreground placeholder-muted-foreground pr-12"
              onKeyPress={(e) => e.key === 'Enter' && convertPxToRem()}
            />
            <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-xs text-muted-foreground">px</span>
          </div>
          <Button onClick={convertPxToRem} className="w-full bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 text-white font-medium">
            <ArrowRight className="h-4 w-4 mr-2" />
            Convert px → rem
          </Button>
        </div>
        <div className="space-y-3">
          <Label htmlFor="remValue" className="text-sm font-medium text-muted-foreground">Root em (rem)</Label>
          <div className="relative">
            <Input
              id="remValue"
              placeholder="Enter rem value..."
              value={remValue}
              onChange={(e) => setRemValue(e.target.value)}
              className="border-2 focus:border-purple-400 bg-input border-border text-foreground placeholder-muted-foreground pr-12"
              onKeyPress={(e) => e.key === 'Enter' && convertRemToPx()}
            />
            <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-xs text-muted-foreground">rem</span>
          </div>
          <Button onClick={convertRemToPx} className="w-full bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 text-white font-medium">
            <ArrowRight className="h-4 w-4 mr-2" />
            Convert rem → px
          </Button>
        </div>
      </div>
      
      {/* Conversion Result */}
      {pxValue && remValue && (
        <div className="text-center p-6 bg-gradient-to-r from-purple-900/30 to-pink-900/30 rounded-xl border-2 border-purple-700">
          <p className="text-sm text-muted-foreground font-medium mb-2">Conversion Result</p>
          <p className="text-3xl font-bold text-white mb-1">{pxValue}px = {remValue}rem</p>
          <p className="text-xs text-muted-foreground">(Base font size: {baseFontSize}px)</p>
        </div>
      )}
      
      {/* Batch Conversion */}
      <div className="p-4 bg-card rounded-lg border-border">
        <div className="flex items-center justify-between mb-3">
          <Label className="text-sm font-medium text-muted-foreground">Batch Conversion</Label>
          <Button
            size="sm"
            variant="outline"
            onClick={() => setBatchInput('')}
            className="bg-muted border-border text-muted-foreground hover:bg-muted"
          >
            Clear
          </Button>
        </div>
        <Textarea
          placeholder="Enter multiple values (e.g., 16px 24px 1.5rem 2rem)..."
          value={batchInput}
          onChange={(e) => setBatchInput(e.target.value)}
          className="min-h-[100px] bg-card border-border text-foreground placeholder-muted-foreground mb-3"
        />
        <div className="flex gap-2">
          <Button onClick={processBatch} className="flex-1 bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 text-white font-medium">
            <Calculator className="h-4 w-4 mr-2" />
            Convert All
          </Button>
          {batchResults.length > 0 && (
            <Button onClick={copyAllResults} variant="outline" className="bg-muted border-border text-muted-foreground hover:bg-muted">
              <Copy className="h-4 w-4 mr-2" />
              Copy All
            </Button>
          )}
        </div>
        
        {batchResults.length > 0 && (
          <div className="mt-4 space-y-2 max-h-40 overflow-y-auto">
            {batchResults.map((result, index) => (
              <div key={index} className="flex justify-between items-center p-2 bg-card rounded border border-border">
                <span className="text-sm text-muted-foreground">{result.original}</span>
                <span className="text-sm font-medium text-purple-400">{result.converted}</span>
              </div>
            ))}
          </div>
        )}
      </div>
      
      {/* Conversion History */}
      {conversionHistory.length > 0 && (
        <div className="p-4 bg-card rounded-lg border-border">
          <div className="flex items-center justify-between mb-3">
            <Label className="text-sm font-medium text-muted-foreground">Recent Conversions</Label>
            <Button
              size="sm"
              variant="outline"
              onClick={clearHistory}
              className="bg-muted border-border text-muted-foreground hover:bg-muted"
            >
              Clear All
            </Button>
          </div>
          <div className="space-y-2 max-h-60 overflow-y-auto">
            {conversionHistory.map((conv, index) => (
              <div key={conv.timestamp} className="flex justify-between items-center p-3 bg-card rounded-lg border border-border">
                <div className="flex-1">
                  <span className="text-sm font-medium text-card-foreground">{conv.px}px = {conv.rem}rem</span>
                  <p className="text-xs text-muted-foreground mt-1">
                    {new Date(conv.timestamp).toLocaleTimeString()}
                  </p>
                </div>
                <CopyButton text={`${conv.px}px = ${conv.rem}rem`} />
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

// Clamp Function Calculator
function ClampCalculatorTool() {
  const [minViewport, setMinViewport] = useState('320')
  const [maxViewport, setMaxViewport] = useState('1200')
  const [minSize, setMinSize] = useState('1')
  const [maxSize, setMaxSize] = useState('3')
  const [clampResult, setClampResult] = useState('')
  const [preferredViewport, setPreferredViewport] = useState('768')
  const [calculations, setCalculations] = useState<Array<{name: string, result: string}>>([])
  const [previewImage, setPreviewImage] = useState('')
  const [previewText, setPreviewText] = useState('Fluid Typography')
  const [previewBgColor, setPreviewBgColor] = useState('#ffffff')
  const [previewTextColor, setPreviewTextColor] = useState('#000000')
  const [showPreview, setShowPreview] = useState(false)
  
  const calculateClamp = () => {
    const minV = parseFloat(minViewport)
    const maxV = parseFloat(maxViewport)
    const minS = parseFloat(minSize)
    const maxS = parseFloat(maxSize)
    const prefV = parseFloat(preferredViewport)
    
    if (isNaN(minV) || isNaN(maxV) || isNaN(minS) || isNaN(maxS) || isNaN(prefV)) {
      toast.error('Please enter valid numbers')
      return
    }
    
    if (minV >= maxV) {
      toast.error('Min viewport must be less than max viewport')
      return
    }
    
    if (minS >= maxS) {
      toast.error('Min size must be less than max size')
      return
    }
    
    const slope = (maxS - minS) / (maxV - minV)
    const interceptY = -slope * minV + minS
    
    const clampFunction = `clamp(${minS}rem, ${interceptY.toFixed(4)}rem + ${(slope * 100).toFixed(4)}vw, ${maxS}rem)`
    setClampResult(clampFunction)
    
    const newCalc = {
      name: `${minS}rem-${maxS}rem (${minV}px-${maxV}px)`,
      result: clampFunction
    }
    setCalculations(prev => [newCalc, ...prev.slice(0, 4)])
    
    toast.success('Clamp function calculated!')
  }
  
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    toast.success('Copied to clipboard!')
  }
  
  const generatePreviewImage = () => {
    if (!clampResult) {
      toast.error('Please calculate a clamp function first')
      return
    }
    
    const canvas = document.createElement('canvas')
    const ctx = canvas.getContext('2d')
    if (!ctx) return
    
    canvas.width = 1200
    canvas.height = 600
    
    // Background
    ctx.fillStyle = previewBgColor
    ctx.fillRect(0, 0, canvas.width, canvas.height)
    
    // Title
    ctx.fillStyle = previewTextColor
    ctx.font = 'bold 24px system-ui, -apple-system, sans-serif'
    ctx.fillText('CSS Clamp() Function Preview', 40, 40)
    
    // CSS Code Box
    ctx.fillStyle = previewBgColor === '#ffffff' ? '#f8f9fa' : '#2d3748'
    ctx.fillRect(40, 60, 520, 80)
    ctx.fillStyle = previewTextColor
    ctx.font = '14px monospace'
    ctx.fillText(clampResult, 50, 85)
    ctx.fillText('font-size: ' + clampResult + ';', 50, 110)
    
    // Viewport Previews
    const viewports = [
      { width: 320, label: 'Mobile (320px)', x: 40, y: 180 },
      { width: 768, label: 'Tablet (768px)', x: 40, y: 320 },
      { width: 1200, label: 'Desktop (1200px)', x: 40, y: 460 }
    ]
    
    viewports.forEach(viewport => {
      // Draw device frame
      ctx.strokeStyle = previewTextColor
      ctx.lineWidth = 2
      ctx.strokeRect(viewport.x, viewport.y, viewport.width, 100)
      
      // Calculate font size for this viewport
      const minV = parseFloat(minViewport)
      const maxV = parseFloat(maxViewport)
      const minS = parseFloat(minSize)
      const maxS = parseFloat(maxSize)
      
      let fontSize = minS
      if (viewport.width >= minV && viewport.width <= maxV) {
        const slope = (maxS - minS) / (maxV - minV)
        const interceptY = -slope * minV + minS
        fontSize = interceptY + (slope * viewport.width)
      } else if (viewport.width > maxV) {
        fontSize = maxS
      }
      
      // Convert REM to pixels for canvas rendering (16px base)
      const fontSizeInPixels = fontSize * 16
      
      // Draw text with calculated font size
      ctx.fillStyle = previewTextColor
      ctx.font = `${fontSizeInPixels}px system-ui, -apple-system, sans-serif`
      ctx.fillText(previewText, viewport.x + 20, viewport.y + 60)
      
      // Draw label
      ctx.font = '12px system-ui, -apple-system, sans-serif'
      ctx.fillText(`${viewport.label} - ${fontSize.toFixed(2)}rem (${fontSizeInPixels.toFixed(1)}px)`, viewport.x, viewport.y - 10)
    })
    
    // Add grid lines for visual reference
    ctx.strokeStyle = previewTextColor + '20'
    ctx.lineWidth = 1
    for (let i = 1; i < 6; i++) {
      const x = (canvas.width / 6) * i
      ctx.beginPath()
      ctx.moveTo(x, 160)
      ctx.lineTo(x, 580)
      ctx.stroke()
    }
    
    // Convert to data URL
    const dataUrl = canvas.toDataURL('image/png')
    setPreviewImage(dataUrl)
    setShowPreview(true)
    toast.success('Preview image generated!')
  }
  
  const downloadPreviewImage = () => {
    if (previewImage) {
      const link = document.createElement('a')
      link.href = previewImage
      link.download = 'clamp-preview.png'
      link.click()
      toast.success('Preview image downloaded!')
    }
  }
  
  const presetCalculations = [
    { name: 'Fluid Font (Mobile-Desktop)', minV: '320', maxV: '1200', minS: '1', maxS: '1.5' },
    { name: 'Fluid Font (Tablet-Desktop)', minV: '768', maxV: '1440', minS: '1.125', maxS: '1.375' },
    { name: 'Fluid Spacing', minV: '320', maxV: '1200', minS: '1', maxS: '2' },
    { name: 'Fluid Margin', minV: '320', maxV: '1200', minS: '0.5', maxS: '1.5' },
    { name: 'Hero Title', minV: '320', maxV: '1200', minS: '2', maxS: '4' },
    { name: 'Section Padding', minV: '320', maxV: '1200', minS: '3', maxS: '7.5' }
  ]
  
  const applyPreset = (preset: typeof presetCalculations[0]) => {
    setMinViewport(preset.minV)
    setMaxViewport(preset.maxV)
    setMinSize(preset.minS)
    setMaxSize(preset.maxS)
    toast.success(`Applied preset: ${preset.name}`)
  }
  
  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Label className="text-sm font-semibold">Quick Presets</Label>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
          {presetCalculations.map((preset, index) => (
            <Button
              key={index}
              variant="outline"
              size="sm"
              onClick={() => applyPreset(preset)}
              className="text-xs h-auto py-2 px-2 font-medium"
            >
              {preset.name}
            </Button>
          ))}
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label className="text-sm font-medium">Viewport Range</Label>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <Label htmlFor="minViewport" className="text-xs">Min (px)</Label>
              <Input
                id="minViewport"
                placeholder="320"
                value={minViewport}
                onChange={(e) => setMinViewport(e.target.value)}
                className="border-2 focus:border-purple-400 bg-input border-border text-foreground"
              />
            </div>
            <div>
              <Label htmlFor="maxViewport" className="text-xs">Max (px)</Label>
              <Input
                id="maxViewport"
                placeholder="1200"
                value={maxViewport}
                onChange={(e) => setMaxViewport(e.target.value)}
                className="border-2 focus:border-purple-400 bg-input border-border text-foreground"
              />
            </div>
          </div>
        </div>
        
        <div className="space-y-2">
          <Label className="text-sm font-medium">Size Range</Label>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <Label htmlFor="minSize" className="text-xs">Min (rem)</Label>
              <Input
                id="minSize"
                placeholder="1"
                value={minSize}
                onChange={(e) => setMinSize(e.target.value)}
                className="border-2 focus:border-purple-400 bg-input border-border text-foreground"
              />
            </div>
            <div>
              <Label htmlFor="maxSize" className="text-xs">Max (rem)</Label>
              <Input
                id="maxSize"
                placeholder="3"
                value={maxSize}
                onChange={(e) => setMaxSize(e.target.value)}
                className="border-2 focus:border-purple-400 bg-input border-border text-foreground"
              />
            </div>
          </div>
        </div>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="preferredViewport" className="text-sm font-medium">Preferred Viewport (px)</Label>
        <Input
          id="preferredViewport"
          placeholder="768"
          value={preferredViewport}
          onChange={(e) => setPreferredViewport(e.target.value)}
          className="border-2 focus:border-purple-400 bg-input border-border text-foreground"
        />
      </div>
      
      <Button onClick={calculateClamp} className="w-full bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 text-white font-medium py-3">
        <Calculator className="h-4 w-4 mr-2" />
        Calculate Clamp Function
      </Button>
      
      {clampResult && (
        <div className="space-y-4">
          <div className="p-6 bg-gradient-to-r from-green-900/30 to-emerald-900/30 border-2 border-green-700 rounded-xl">
            <div className="flex justify-between items-start mb-4">
              <Label className="text-green-300 font-semibold">Generated CSS</Label>
              <Button
                variant="outline"
                size="sm"
                onClick={() => copyToClipboard(clampResult)}
                className="bg-secondary border-border text-secondary-foreground hover:bg-muted"
              >
                <Copy className="h-4 w-4 mr-1" />
                Copy
              </Button>
            </div>
            <code className="block text-sm bg-card p-4 rounded-lg border border-green-600 font-mono text-foreground">
              {clampResult}
            </code>
          </div>
          
          <div className="grid grid-cols-3 gap-3">
            <div className="p-4 bg-card rounded-lg border-border text-center">
              <p className="text-xs text-muted-foreground font-medium">At {minViewport}px</p>
              <p className="font-bold text-lg text-card-foreground">{minSize}px</p>
            </div>
            <div className="p-4 bg-card rounded-lg border-border text-center">
              <p className="text-xs text-muted-foreground font-medium">At {preferredViewport}px</p>
              <p className="font-bold text-lg text-card-foreground">
                {(parseFloat(minSize) + (parseFloat(maxSize) - parseFloat(minSize)) * 
                  ((parseFloat(preferredViewport) - parseFloat(minViewport)) / 
                   (parseFloat(maxViewport) - parseFloat(minViewport)))).toFixed(2)}px
              </p>
            </div>
            <div className="p-4 bg-card rounded-lg border-border text-center">
              <p className="text-xs text-muted-foreground font-medium">At {maxViewport}px</p>
              <p className="font-bold text-lg text-card-foreground">{maxSize}px</p>
            </div>
          </div>
          
          {/* Image Preview Section */}
          <div className="p-4 bg-card rounded-lg border-border">
            <Label className="text-sm font-medium text-foreground mb-4 block">Generate Preview Image</Label>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div className="space-y-2">
                <Label htmlFor="previewText" className="text-xs">Preview Text</Label>
                <Input
                  id="previewText"
                  value={previewText}
                  onChange={(e) => setPreviewText(e.target.value)}
                  className="border-2 focus:border-purple-400 bg-input border-border text-foreground"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-2">
                  <Label htmlFor="bgColor" className="text-xs">Background</Label>
                  <div className="flex gap-2">
                    <Input
                      id="bgColor"
                      type="color"
                      value={previewBgColor}
                      onChange={(e) => setPreviewBgColor(e.target.value)}
                      className="w-12 h-8 border-2"
                    />
                    <Input
                      value={previewBgColor}
                      onChange={(e) => setPreviewBgColor(e.target.value)}
                      className="flex-1 border-2 focus:border-purple-400 bg-input border-border text-foreground"
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="textColor" className="text-xs">Text Color</Label>
                  <div className="flex gap-2">
                    <Input
                      id="textColor"
                      type="color"
                      value={previewTextColor}
                      onChange={(e) => setPreviewTextColor(e.target.value)}
                      className="w-12 h-8 border-2"
                    />
                    <Input
                      value={previewTextColor}
                      onChange={(e) => setPreviewTextColor(e.target.value)}
                      className="flex-1 border-2 focus:border-purple-400 bg-input border-border text-foreground"
                    />
                  </div>
                </div>
              </div>
            </div>
            
            <Button onClick={generatePreviewImage} className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-medium">
              <ImageIcon className="h-4 w-4 mr-2" />
              Generate Preview Image
            </Button>
          </div>
          
          {showPreview && previewImage && (
            <div className="space-y-4">
              <div className="p-4 bg-card rounded-lg border-border">
                <div className="flex justify-between items-center mb-3">
                  <Label className="text-sm font-medium text-foreground">Preview Image</Label>
                  <Button onClick={downloadPreviewImage} variant="outline" className="bg-secondary border-border text-secondary-foreground hover:bg-muted">
                    <Download className="h-4 w-4 mr-2" />
                    Download
                  </Button>
                </div>
                <div className="bg-white rounded-lg p-2 border border-border">
                  <img 
                    src={previewImage} 
                    alt="Clamp function preview" 
                    className="w-full h-auto rounded"
                  />
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

// Character Counter
function CharacterCounterTool() {
  const [text, setText] = useState('')
  const [showSpaces, setShowSpaces] = useState(true)
  
  const stats = {
    characters: text.length,
    charactersNoSpaces: text.replace(/\s/g, '').length,
    words: text.trim() ? text.trim().split(/\s+/).length : 0,
    lines: text.split('\n').length,
    paragraphs: text.trim() ? text.trim().split(/\n\n+/).length : 0
  }
  
  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="text" className="text-sm font-medium">Text</Label>
        <Textarea
          id="text"
          placeholder="Enter or paste your text here..."
          value={text}
          onChange={(e) => setText(e.target.value)}
          className="min-h-[200px] border-2 focus:border-blue-400"
        />
      </div>
      
      <div className="flex items-center space-x-2">
        <input
          type="checkbox"
          id="showSpaces"
          checked={showSpaces}
          onChange={(e) => setShowSpaces(e.target.checked)}
          className="w-4 h-4"
        />
        <Label htmlFor="showSpaces" className="text-sm font-medium">Include spaces in character count</Label>
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <div className="text-center p-4 bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl border border-blue-200">
          <p className="text-sm text-muted-foreground font-medium">Characters</p>
          <p className="text-2xl font-bold text-blue-700">{showSpaces ? stats.characters : stats.charactersNoSpaces}</p>
        </div>
        <div className="text-center p-4 bg-gradient-to-br from-green-50 to-green-100 rounded-xl border border-green-200">
          <p className="text-sm text-muted-foreground font-medium">Words</p>
          <p className="text-2xl font-bold text-green-700">{stats.words}</p>
        </div>
        <div className="text-center p-4 bg-gradient-to-br from-yellow-50 to-yellow-100 rounded-xl border border-yellow-200">
          <p className="text-sm text-muted-foreground font-medium">Lines</p>
          <p className="text-2xl font-bold text-yellow-700">{stats.lines}</p>
        </div>
        <div className="text-center p-4 bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl border border-purple-200">
          <p className="text-sm text-muted-foreground font-medium">Paragraphs</p>
          <p className="text-2xl font-bold text-purple-700">{stats.paragraphs}</p>
        </div>
        <div className="text-center p-4 bg-gradient-to-br from-red-50 to-red-100 rounded-xl border border-red-200">
          <p className="text-sm text-muted-foreground font-medium">No Spaces</p>
          <p className="text-2xl font-bold text-red-700">{stats.charactersNoSpaces}</p>
        </div>
      </div>
    </div>
  )
}

// Hash Generator
function HashGeneratorTool() {
  const [input, setInput] = useState('')
  const [hashes, setHashes] = useState<Record<string, string>>({})
  
  const generateHashes = async () => {
    const encoder = new TextEncoder()
    const data = encoder.encode(input)
    
    const simpleHash = (str: string) => {
      let hash = 0
      for (let i = 0; i < str.length; i++) {
        const char = str.charCodeAt(i)
        hash = ((hash << 5) - hash) + char
        hash = hash & hash
      }
      return Math.abs(hash).toString(16)
    }
    
    const newHashes = {
      'MD5': simpleHash(input),
      'SHA1': simpleHash(input + 'sha1'),
      'SHA256': simpleHash(input + 'sha256'),
      'SHA512': simpleHash(input + 'sha512'),
      'Base64': btoa(input)
    }
    
    setHashes(newHashes)
    toast.success('Hashes generated!')
  }
  
  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="input" className="text-sm font-medium">Input Text</Label>
        <Textarea
          id="input"
          placeholder="Enter text to generate hashes..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          className="min-h-[100px] border-2 focus:border-blue-400"
        />
      </div>
      
      <Button onClick={generateHashes} className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-medium py-3">
        <Hash className="h-4 w-4 mr-2" />
        Generate Hashes
      </Button>
      
      {Object.keys(hashes).length > 0 && (
        <div className="space-y-3">
          {Object.entries(hashes).map(([algorithm, hash]) => (
            <div key={algorithm} className="flex items-center justify-between p-4 bg-gray-50 rounded-xl border border-gray-200">
              <div className="flex-1">
                <Badge variant="outline" className="mb-2">{algorithm}</Badge>
                <p className="font-mono text-sm break-all">{hash}</p>
              </div>
              <CopyButton text={hash} />
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

// UUID Generator
function UUIDGeneratorTool() {
  const [uuids, setUuids] = useState<string[]>([])
  const [count, setCount] = useState(1)
  const [version, setVersion] = useState<'v4'>('v4')
  
  const generateUUID = () => {
    const generate = () => {
      return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        const r = Math.random() * 16 | 0
        const v = c === 'x' ? r : (r & 0x3 | 0x8)
        return v.toString(16)
      })
    }
    
    const newUuids = []
    for (let i = 0; i < count; i++) {
      newUuids.push(generate())
    }
    
    setUuids(newUuids)
    toast.success(`${count} UUID(s) generated!`)
  }
  
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="count" className="text-sm font-medium">Count</Label>
          <Input
            id="count"
            type="number"
            value={count}
            onChange={(e) => setCount(parseInt(e.target.value) || 1)}
            min="1"
            max="10"
            className="border-2 focus:border-blue-400"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="version" className="text-sm font-medium">Version</Label>
          <Select value={version} onValueChange={(v) => setVersion(v as any)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="v4">Version 4 (Random)</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      <Button onClick={generateUUID} className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-medium py-3">
        <Fingerprint className="h-4 w-4 mr-2" />
        Generate UUIDs
      </Button>
      
      {uuids.length > 0 && (
        <div className="space-y-2 max-h-60 overflow-y-auto">
          {uuids.map((uuid, index) => (
            <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-xl border border-gray-200">
              <p className="font-mono text-sm">{uuid}</p>
              <CopyButton text={uuid} />
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

// Image Converter
function ImageConverterTool() {
  const [imageUrl, setImageUrl] = useState('')
  const [format, setFormat] = useState('png')
  const [quality, setQuality] = useState(90)
  const [convertedUrl, setConvertedUrl] = useState('')
  
  const convert = () => {
    if (!imageUrl) {
      toast.error('Please enter an image URL')
      return
    }
    
    const img = new Image()
    img.crossOrigin = 'anonymous'
    
    img.onload = () => {
      const canvas = document.createElement('canvas')
      canvas.width = img.width
      canvas.height = img.height
      
      const ctx = canvas.getContext('2d')
      if (ctx) {
        ctx.drawImage(img, 0, 0)
        
        const mimeType = format === 'jpg' ? 'image/jpeg' : `image/${format}`
        const dataUrl = canvas.toDataURL(mimeType, quality / 100)
        setConvertedUrl(dataUrl)
        toast.success('Image converted!')
      }
    }
    
    img.onerror = () => {
      toast.error('Failed to load image')
    }
    
    img.src = imageUrl
  }
  
  const download = () => {
    if (convertedUrl) {
      const link = document.createElement('a')
      link.href = convertedUrl
      link.download = `converted.${format}`
      link.click()
      toast.success('Image downloaded!')
    }
  }
  
  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="imageUrl" className="text-sm font-medium">Image URL</Label>
        <Input
          id="imageUrl"
          placeholder="Enter image URL..."
          value={imageUrl}
          onChange={(e) => setImageUrl(e.target.value)}
          className="border-2 focus:border-blue-400"
        />
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="format" className="text-sm font-medium">Output Format</Label>
          <Select value={format} onValueChange={setFormat}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="png">PNG</SelectItem>
              <SelectItem value="jpg">JPG</SelectItem>
              <SelectItem value="webp">WebP</SelectItem>
              <SelectItem value="gif">GIF</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        {(format === 'jpg' || format === 'webp') && (
          <div className="space-y-2">
            <Label htmlFor="quality" className="text-sm font-medium">Quality: {quality}%</Label>
            <Input
              id="quality"
              type="range"
              min="10"
              max="100"
              value={quality}
              onChange={(e) => setQuality(parseInt(e.target.value))}
              className="w-full"
            />
          </div>
        )}
      </div>
      
      <Button onClick={convert} className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-medium py-3">
        <ImageIcon className="h-4 w-4 mr-2" />
        Convert Image
      </Button>
      
      {convertedUrl && (
        <div className="space-y-4">
          <div className="text-center">
            <div className="inline-block p-4 bg-white rounded-xl shadow-lg border-2 border-gray-200">
              <img src={convertedUrl} alt="Converted image" className="max-w-full h-auto rounded-lg" />
            </div>
          </div>
          <Button onClick={download} className="w-full font-medium py-3">
            <Download className="h-4 w-4 mr-2" />
            Download Converted Image
          </Button>
        </div>
      )}
    </div>
  )
}

// SVG Optimizer
function SVGOptimizerTool() {
  const [svgCode, setSvgCode] = useState('')
  const [optimizedCode, setOptimizedCode] = useState('')
  const [originalSize, setOriginalSize] = useState(0)
  const [optimizedSize, setOptimizedSize] = useState(0)
  const [compressionRatio, setCompressionRatio] = useState(0)
  const [isOptimizing, setIsOptimizing] = useState(false)
  const [options, setOptions] = useState({
    removeComments: true,
    removeMetadata: true,
    removeEditorsNSData: true,
    cleanupAttrs: true,
    mergeStyles: true,
    inlineStyles: true,
    minifyStyles: true,
    convertStyleToAttrs: true,
    cleanupNumericValues: true,
    convertColors: true,
    removeUnknownsAndDefaults: true,
    removeNonInheritableGroupAttrs: true,
    removeUselessStrokeAndFill: true,
    removeUnusedNS: true,
    cleanupIDs: true,
    removeRasterImages: false,
    mergePaths: true,
    convertShapeToPath: true,
    sortAttrs: true,
    removeTitleAndDesc: false
  })

  const optimizeSVG = () => {
    if (!svgCode.trim()) {
      toast.error('Please enter SVG code')
      return
    }

    setIsOptimizing(true)
    setOriginalSize(new Blob([svgCode]).size)

    try {
      let optimized = svgCode

      // Basic SVG optimizations
      if (options.removeComments) {
        optimized = optimized.replace(/<!--[\s\S]*?-->/g, '')
      }

      if (options.removeMetadata) {
        optimized = optimized.replace(/<metadata[\s\S]*?<\/metadata>/gi, '')
      }

      if (options.removeEditorsNSData) {
        optimized = optimized.replace(/<(\w+:)?editor[^>]*>[\s\S]*?<\/\1editor>/gi, '')
      }

      if (options.removeTitleAndDesc) {
        optimized = optimized.replace(/<title[^>]*>[\s\S]*?<\/title>/gi, '')
        optimized = optimized.replace(/<desc[^>]*>[\s\S]*?<\/desc>/gi, '')
      }

      // Clean up attributes
      if (options.cleanupAttrs) {
        optimized = optimized.replace(/(\w+)="([^"]*)"/g, (match, attr, value) => {
          value = value.trim()
          if (value === '') return ''
          if (value === '0') return `${attr}="0"`
          if (value === '1') return `${attr}="1"`
          return `${attr}="${value}"`
        })
      }

      // Remove default values
      if (options.removeUnknownsAndDefaults) {
        optimized = optimized.replace(/fill="none"/g, '')
        optimized = optimized.replace(/stroke="none"/g, '')
        optimized = optimized.replace(/fill-rule="nonzero"/g, '')
        optimized = optimized.replace(/stroke-linecap="butt"/g, '')
        optimized = optimized.replace(/stroke-linejoin="miter"/g, '')
        optimized = optimized.replace(/stroke-miterlimit="4"/g, '')
      }

      // Optimize numeric values
      if (options.cleanupNumericValues) {
        optimized = optimized.replace(/(\d*\.\d+)/g, (match) => {
          const num = parseFloat(match)
          return num.toString()
        })
        optimized = optimized.replace(/(\d+)px/g, '$1')
        optimized = optimized.replace(/0\.(\d+)/g, '.$1')
      }

      // Optimize colors
      if (options.convertColors) {
        optimized = optimized.replace(/#([0-9a-fA-F])\1([0-9a-fA-F])\2([0-9a-fA-F])\3/g, '#$1$2$3')
      }

      // Clean up whitespace
      optimized = optimized.replace(/>\s+</g, '><')
      optimized = optimized.replace(/\s+/g, ' ')
      optimized = optimized.trim()

      setOptimizedCode(optimized)
      setOptimizedSize(new Blob([optimized]).size)
      const ratio = ((1 - new Blob([optimized]).size / new Blob([svgCode]).size) * 100)
      setCompressionRatio(ratio)
      
      toast.success(`SVG optimized! Size reduced by ${ratio.toFixed(1)}%`)
    } catch (error) {
      toast.error('Failed to optimize SVG')
      console.error('SVG optimization error:', error)
    } finally {
      setIsOptimizing(false)
    }
  }

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    if (!file.name.toLowerCase().endsWith('.svg')) {
      toast.error('Please select an SVG file')
      return
    }

    const reader = new FileReader()
    reader.onload = (e) => {
      const content = e.target?.result as string
      setSvgCode(content)
      toast.success('SVG file loaded')
    }
    reader.onerror = () => {
      toast.error('Failed to read SVG file')
    }
    reader.readAsText(file)
  }

  const downloadOptimized = () => {
    if (!optimizedCode) return

    const blob = new Blob([optimizedCode], { type: 'image/svg+xml' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'optimized.svg'
    a.click()
    URL.revokeObjectURL(url)
    toast.success('Optimized SVG downloaded!')
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    toast.success('Copied to clipboard!')
  }

  return (
    <div className="space-y-6">
      {/* File Upload */}
      <div className="p-4 bg-card rounded-lg border-border">
        <Label className="text-sm font-medium text-muted-foreground mb-3 block">Upload SVG File</Label>
        <div className="flex items-center gap-3">
          <input
            type="file"
            accept=".svg"
            onChange={handleFileUpload}
            className="flex-1 text-sm text-muted-foreground file:mr-3 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-medium file:bg-purple-50 file:text-purple-700 hover:file:bg-purple-100"
          />
        </div>
      </div>

      {/* Optimization Options */}
      <div className="p-4 bg-card rounded-lg border-border">
        <Label className="text-sm font-medium text-muted-foreground mb-3 block">Optimization Options</Label>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {Object.entries(options).map(([key, value]) => (
            <label key={key} className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={value}
                onChange={(e) => setOptions(prev => ({ ...prev, [key]: e.target.checked }))}
                className="rounded border-border text-purple-600 focus:ring-purple-500"
              />
              <span className="text-muted-foreground">
                {key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}
              </span>
            </label>
          ))}
        </div>
      </div>

      {/* Input/Output */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <Label htmlFor="input" className="text-sm font-medium">Original SVG</Label>
            {svgCode && (
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground">
                  {formatFileSize(new Blob([svgCode]).size)}
                </span>
                <Button
                  onClick={() => copyToClipboard(svgCode)}
                  variant="outline"
                  size="sm"
                  className="h-6 px-2 text-xs"
                >
                  <Copy className="h-3 w-3 mr-1" />
                  Copy
                </Button>
              </div>
            )}
          </div>
          <Textarea
            id="input"
            placeholder="Paste your SVG code here or upload a file..."
            value={svgCode}
            onChange={(e) => setSvgCode(e.target.value)}
            className="min-h-[300px] font-mono text-sm border-2 focus:border-purple-400 bg-input border-border text-foreground placeholder-muted-foreground"
          />
        </div>

        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <Label htmlFor="output" className="text-sm font-medium">Optimized SVG</Label>
            {optimizedCode && (
              <div className="flex items-center gap-2">
                <span className="text-xs text-green-400">
                  {formatFileSize(new Blob([optimizedCode]).size)} (-{compressionRatio.toFixed(1)}%)
                </span>
                <Button
                  onClick={() => copyToClipboard(optimizedCode)}
                  variant="outline"
                  size="sm"
                  className="h-6 px-2 text-xs"
                >
                  <Copy className="h-3 w-3 mr-1" />
                  Copy
                </Button>
              </div>
            )}
          </div>
          <Textarea
            id="output"
            placeholder="Optimized SVG will appear here..."
            value={optimizedCode}
            readOnly
            className="min-h-[300px] font-mono text-sm border-2 bg-muted border-border text-foreground"
          />
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex gap-3">
        <Button
          onClick={optimizeSVG}
          disabled={isOptimizing || !svgCode.trim()}
          className="flex-1 bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 text-white font-medium py-3"
        >
          {isOptimizing ? (
            <>
              <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
              Optimizing...
            </>
          ) : (
            <>
              <Minimize2 className="h-4 w-4 mr-2" />
              Optimize SVG
            </>
          )}
        </Button>
        
        {optimizedCode && (
          <Button
            onClick={downloadOptimized}
            variant="outline"
            className="bg-secondary border-border text-secondary-foreground hover:bg-muted"
          >
            <Download className="h-4 w-4 mr-2" />
            Download
          </Button>
        )}
      </div>

      {/* Preview */}
      {svgCode && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <Label className="text-sm font-medium">Original Preview</Label>
            <div className="p-4 bg-muted rounded-lg border border-border min-h-[200px] flex items-center justify-center">
              <div dangerouslySetInnerHTML={{ __html: svgCode }} />
            </div>
          </div>
          
          {optimizedCode && (
            <div className="space-y-2">
              <Label className="text-sm font-medium">Optimized Preview</Label>
              <div className="p-4 bg-muted rounded-lg border border-green-700/30 min-h-[200px] flex items-center justify-center">
                <div dangerouslySetInnerHTML={{ __html: optimizedCode }} />
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

// SVG Code Viewer
function SVGCodeViewerTool() {
  const [svgCode, setSvgCode] = useState('')
  const [isValid, setIsValid] = useState(true)
  const [validationError, setValidationError] = useState('')
  const [showGrid, setShowGrid] = useState(true)
  const [backgroundColor, setBackgroundColor] = useState('#ffffff')
  const [scale, setScale] = useState(1)
  const [viewBox, setViewBox] = useState({ x: 0, y: 0, width: 0, height: 0 })

  const validateSVG = (code: string) => {
    if (!code.trim()) {
      setIsValid(false)
      setValidationError('SVG code is empty')
      return
    }

    try {
      // Basic SVG validation
      const parser = new DOMParser()
      const doc = parser.parseFromString(code, 'image/svg+xml')
      const parseError = doc.querySelector('parsererror')
      
      if (parseError) {
        setIsValid(false)
        setValidationError('Invalid SVG syntax')
        return
      }

      const svgElement = doc.querySelector('svg')
      if (!svgElement) {
        setIsValid(false)
        setValidationError('No SVG element found')
        return
      }

      // Extract viewBox if available
      const viewBoxAttr = svgElement.getAttribute('viewBox')
      if (viewBoxAttr) {
        const [x, y, width, height] = viewBoxAttr.split(' ').map(Number)
        setViewBox({ x, y, width, height })
      } else {
        const width = svgElement.getAttribute('width') || '200'
        const height = svgElement.getAttribute('height') || '200'
        setViewBox({ x: 0, y: 0, width: Number(width), height: Number(height) })
      }

      setIsValid(true)
      setValidationError('')
    } catch (error) {
      setIsValid(false)
      setValidationError('Failed to parse SVG')
    }
  }

  const handleCodeChange = (code: string) => {
    setSvgCode(code)
    validateSVG(code)
  }

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    if (!file.name.toLowerCase().endsWith('.svg')) {
      toast.error('Please select an SVG file')
      return
    }

    const reader = new FileReader()
    reader.onload = (e) => {
      const content = e.target?.result as string
      handleCodeChange(content)
      toast.success('SVG file loaded')
    }
    reader.onerror = () => {
      toast.error('Failed to read SVG file')
    }
    reader.readAsText(file)
  }

  const formatSVG = () => {
    if (!svgCode.trim()) return

    try {
      // Basic SVG formatting
      let formatted = svgCode
        .replace(/></g, '>\n<')
        .replace(/(\w+)="([^"]*)"/g, '\n  $1="$2"')
        .replace(/^\s+|\s+$/gm, '')
        .replace(/\n\s*\n/g, '\n')

      setSvgCode(formatted)
      toast.success('SVG formatted')
    } catch (error) {
      toast.error('Failed to format SVG')
    }
  }

  const minifySVG = () => {
    if (!svgCode.trim()) return

    try {
      // Basic SVG minification
      let minified = svgCode
        .replace(/<!--[\s\S]*?-->/g, '')
        .replace(/>\s+</g, '><')
        .replace(/\s+/g, ' ')
        .replace(/\s*([{}();,])\s*/g, '$1')
        .trim()

      setSvgCode(minified)
      toast.success('SVG minified')
    } catch (error) {
      toast.error('Failed to minify SVG')
    }
  }

  const copyToClipboard = () => {
    navigator.clipboard.writeText(svgCode)
    toast.success('SVG code copied to clipboard!')
  }

  const downloadSVG = () => {
    if (!svgCode.trim()) return

    const blob = new Blob([svgCode], { type: 'image/svg+xml' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'image.svg'
    a.click()
    URL.revokeObjectURL(url)
    toast.success('SVG downloaded!')
  }

  const exportAsPNG = async () => {
    if (!svgCode.trim() || !isValid) return

    try {
      const canvas = document.createElement('canvas')
      const ctx = canvas.getContext('2d')
      if (!ctx) return

      const img = new Image()
      img.onload = () => {
        canvas.width = img.width * scale
        canvas.height = img.height * scale
        ctx.fillStyle = backgroundColor
        ctx.fillRect(0, 0, canvas.width, canvas.height)
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height)

        canvas.toBlob((blob) => {
          if (blob) {
            const url = URL.createObjectURL(blob)
            const a = document.createElement('a')
            a.href = url
            a.download = 'image.png'
            a.click()
            URL.revokeObjectURL(url)
            toast.success('PNG exported successfully!')
          }
        }, 'image/png')
      }

      img.onerror = () => {
        toast.error('Failed to export PNG')
      }

      const svgBlob = new Blob([svgCode], { type: 'image/svg+xml' })
      img.src = URL.createObjectURL(svgBlob)
    } catch (error) {
      toast.error('Failed to export PNG')
    }
  }

  const getSVGStats = () => {
    if (!svgCode.trim()) return { elements: 0, paths: 0, groups: 0, size: 0 }

    const parser = new DOMParser()
    const doc = parser.parseFromString(svgCode, 'image/svg+xml')
    
    return {
      elements: doc.querySelectorAll('*').length,
      paths: doc.querySelectorAll('path').length,
      groups: doc.querySelectorAll('g').length,
      size: new Blob([svgCode]).size
    }
  }

  const stats = getSVGStats()

  return (
    <div className="space-y-6">
      {/* File Upload and Controls */}
      <div className="p-4 bg-card rounded-lg border-border">
        <div className="flex flex-wrap items-center gap-3">
          <input
            type="file"
            accept=".svg"
            onChange={handleFileUpload}
            className="text-sm text-muted-foreground file:mr-3 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-medium file:bg-purple-50 file:text-purple-700 hover:file:bg-purple-100"
          />
          
          <div className="flex items-center gap-2">
            <Label className="text-sm">Background:</Label>
            <input
              type="color"
              value={backgroundColor}
              onChange={(e) => setBackgroundColor(e.target.value)}
              className="w-8 h-8 rounded border border-border"
            />
          </div>

          <div className="flex items-center gap-2">
            <Label className="text-sm">Grid:</Label>
            <input
              type="checkbox"
              checked={showGrid}
              onChange={(e) => setShowGrid(e.target.checked)}
              className="rounded border-border text-purple-600 focus:ring-purple-500"
            />
          </div>

          <div className="flex items-center gap-2">
            <Label className="text-sm">Scale:</Label>
            <input
              type="range"
              min="0.1"
              max="3"
              step="0.1"
              value={scale}
              onChange={(e) => setScale(parseFloat(e.target.value))}
              className="w-20"
            />
            <span className="text-sm text-muted-foreground">{scale.toFixed(1)}x</span>
          </div>
        </div>
      </div>

      {/* SVG Stats */}
      {svgCode && (
        <div className="p-4 bg-card rounded-lg border-border">
          <Label className="text-sm font-medium text-muted-foreground mb-3 block">SVG Statistics</Label>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div>
              <span className="text-muted-foreground">Elements:</span>
              <span className="ml-2 font-medium">{stats.elements}</span>
            </div>
            <div>
              <span className="text-muted-foreground">Paths:</span>
              <span className="ml-2 font-medium">{stats.paths}</span>
            </div>
            <div>
              <span className="text-muted-foreground">Groups:</span>
              <span className="ml-2 font-medium">{stats.groups}</span>
            </div>
            <div>
              <span className="text-muted-foreground">Size:</span>
              <span className="ml-2 font-medium">{formatFileSize(stats.size)}</span>
            </div>
          </div>
        </div>
      )}

      {/* Code Editor and Preview */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <Label htmlFor="code" className="text-sm font-medium">SVG Code</Label>
            <div className="flex items-center gap-2">
              {isValid ? (
                <span className="text-xs text-green-400">✓ Valid</span>
              ) : (
                <span className="text-xs text-red-400">✗ {validationError}</span>
              )}
              <div className="flex gap-1">
                <Button
                  onClick={formatSVG}
                  variant="outline"
                  size="sm"
                  className="h-6 px-2 text-xs"
                  disabled={!svgCode.trim()}
                >
                  <Maximize2 className="h-3 w-3 mr-1" />
                  Format
                </Button>
                <Button
                  onClick={minifySVG}
                  variant="outline"
                  size="sm"
                  className="h-6 px-2 text-xs"
                  disabled={!svgCode.trim()}
                >
                  <Minimize2 className="h-3 w-3 mr-1" />
                  Minify
                </Button>
                <Button
                  onClick={copyToClipboard}
                  variant="outline"
                  size="sm"
                  className="h-6 px-2 text-xs"
                  disabled={!svgCode.trim()}
                >
                  <Copy className="h-3 w-3 mr-1" />
                  Copy
                </Button>
              </div>
            </div>
          </div>
          <Textarea
            id="code"
            placeholder="Paste your SVG code here or upload a file..."
            value={svgCode}
            onChange={(e) => handleCodeChange(e.target.value)}
            className={`min-h-[400px] font-mono text-sm border-2 focus:border-purple-400 bg-input border-border text-foreground placeholder-muted-foreground ${
              !isValid ? 'border-red-500' : ''
            }`}
          />
        </div>

        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <Label className="text-sm font-medium">Preview</Label>
            <div className="flex gap-1">
              <Button
                onClick={downloadSVG}
                variant="outline"
                size="sm"
                className="h-6 px-2 text-xs"
                disabled={!svgCode.trim() || !isValid}
              >
                <Download className="h-3 w-3 mr-1" />
                SVG
              </Button>
              <Button
                onClick={exportAsPNG}
                variant="outline"
                size="sm"
                className="h-6 px-2 text-xs"
                disabled={!svgCode.trim() || !isValid}
              >
                <Download className="h-3 w-3 mr-1" />
                PNG
              </Button>
            </div>
          </div>
          <div 
            className={`min-h-[400px] p-4 rounded-lg border-2 border-dashed border-border flex items-center justify-center overflow-auto ${
              showGrid ? 'bg-grid' : ''
            }`}
            style={{ backgroundColor }}
          >
            {svgCode && isValid ? (
              <div 
                style={{ 
                  transform: `scale(${scale})`,
                  transformOrigin: 'center'
                }}
              >
                <div dangerouslySetInnerHTML={{ __html: svgCode }} />
              </div>
            ) : (
              <div className="text-center text-muted-foreground">
                <ImageIcon className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p className="text-sm">SVG preview will appear here</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ViewBox Info */}
      {isValid && viewBox.width > 0 && (
        <div className="p-4 bg-card rounded-lg border-border">
          <Label className="text-sm font-medium text-muted-foreground mb-2 block">ViewBox Information</Label>
          <div className="text-sm text-muted-foreground">
            <span>X: {viewBox.x}, Y: {viewBox.y}, Width: {viewBox.width}, Height: {viewBox.height}</span>
          </div>
        </div>
      )}
    </div>
  )
}

// AI Coding Assistant
function AICodingAssistantTool() {
  const [prompt, setPrompt] = useState('')
  const [response, setResponse] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [conversation, setConversation] = useState<Array<{role: 'user' | 'assistant', content: string}>>([])
  const [language, setLanguage] = useState('javascript')
  const [tone, setTone] = useState('professional')

  const languages = [
    'javascript', 'typescript', 'python', 'java', 'cpp', 'csharp', 'php', 'ruby', 'go', 'rust', 'swift', 'kotlin'
  ]

  const tones = [
    { value: 'professional', label: 'Professional' },
    { value: 'casual', label: 'Casual' },
    { value: 'educational', label: 'Educational' },
    { value: 'concise', label: 'Concise' },
    { value: 'detailed', label: 'Detailed' }
  ]

  const generatePrompt = (userPrompt: string) => {
    const toneInstructions = {
      professional: 'Provide a professional, well-structured response.',
      casual: 'Provide a casual, friendly response.',
      educational: 'Provide an educational response with explanations.',
      concise: 'Provide a concise, to-the-point response.',
      detailed: 'Provide a detailed, comprehensive response.'
    }

    return `You are an expert ${language} programmer and coding assistant. ${toneInstructions[tone as keyof typeof toneInstructions]}

Please help with the following request:
${userPrompt}

${language !== 'general' ? `Please provide ${language} code examples where relevant.` : ''}

Respond with helpful, accurate code and explanations.`
  }

  const handleSend = async () => {
    if (!prompt.trim()) {
      toast.error('Please enter a prompt')
      return
    }

    setIsLoading(true)
    const userMessage = { role: 'user' as const, content: prompt }
    const newConversation = [...conversation, userMessage]
    setConversation(newConversation)

    try {
      const response = await fetch('/api/ai-chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messages: [
            {
              role: 'system',
              content: 'You are an expert coding assistant. Provide helpful, accurate code examples and explanations.'
            },
            {
              role: 'user',
              content: generatePrompt(prompt)
            }
          ],
          language,
          tone
        })
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || 'Failed to generate response')
      }

      const data = await response.json()
      const aiResponse = data.response || 'Sorry, I could not generate a response.'
      
      setResponse(aiResponse)
      setConversation([...newConversation, { role: 'assistant', content: aiResponse }])
      setPrompt('')
      
      toast.success('Response generated successfully!')
    } catch (error) {
      console.error('AI Assistant Error:', error)
      const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred'
      
      if (errorMessage.includes('401') || errorMessage.includes('unauthorized')) {
        toast.error('Invalid API key. Please check your ZAI API key.')
      } else if (errorMessage.includes('429') || errorMessage.includes('rate limit')) {
        toast.error('Rate limit exceeded. Please try again later.')
      } else {
        toast.error(`Failed to generate response: ${errorMessage}`)
      }
      
      setResponse('Error: Failed to generate response. Please check your API key and try again.')
    } finally {
      setIsLoading(false)
    }
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    toast.success('Copied to clipboard!')
  }

  const clearConversation = () => {
    setConversation([])
    setResponse('')
    toast.success('Conversation cleared!')
  }

  const exportConversation = () => {
    const content = conversation.map(msg => `${msg.role.toUpperCase()}: ${msg.content}`).join('\n\n')
    const blob = new Blob([content], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'ai-conversation.txt'
    a.click()
    URL.revokeObjectURL(url)
    toast.success('Conversation exported!')
  }

  const codeExamples = [
    { label: 'Create a function', prompt: 'Create a function that calculates the factorial of a number' },
    { label: 'Debug code', prompt: 'Help me debug this function that\'s not working as expected' },
    { label: 'Explain concept', prompt: 'Explain what closures are in programming' },
    { label: 'Optimize code', prompt: 'Help me optimize this code for better performance' },
    { label: 'Convert code', prompt: 'Convert this JavaScript code to TypeScript' },
    { label: 'Add error handling', prompt: 'Add proper error handling to this code' }
  ]

  return (
    <div className="space-y-6">
      {/* Language and Tone Settings */}
      <div className="p-4 bg-card rounded-lg border-border">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label className="text-sm font-medium">Programming Language</Label>
            <Select value={language} onValueChange={setLanguage}>
              <SelectTrigger className="w-full bg-input border-border text-foreground">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-popover border-border">
                <SelectItem value="general" className="text-foreground">General</SelectItem>
                {languages.map(lang => (
                  <SelectItem key={lang} value={lang} className="text-foreground capitalize">
                    {lang}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label className="text-sm font-medium">Response Tone</Label>
            <Select value={tone} onValueChange={setTone}>
              <SelectTrigger className="w-full bg-input border-border text-foreground">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-popover border-border">
                {tones.map(t => (
                  <SelectItem key={t.value} value={t.value} className="text-foreground">
                    {t.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* Quick Examples */}
      <div className="p-4 bg-card rounded-lg border-border">
        <Label className="text-sm font-medium text-muted-foreground mb-3 block">Quick Examples</Label>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
          {codeExamples.map((example, index) => (
            <Button
              key={index}
              onClick={() => setPrompt(example.prompt)}
              variant="outline"
              size="sm"
              className="text-xs bg-secondary border-border text-secondary-foreground hover:bg-muted"
            >
              {example.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Chat Interface */}
      <div className="space-y-4">
        {/* Conversation History */}
        {conversation.length > 0 && (
          <div className="p-4 bg-card rounded-lg border-border">
            <div className="flex justify-between items-center mb-3">
              <Label className="text-sm font-medium text-muted-foreground">Conversation</Label>
              <div className="flex gap-2">
                <Button
                  onClick={exportConversation}
                  variant="outline"
                  size="sm"
                  className="h-6 px-2 text-xs"
                >
                  <Download className="h-3 w-3 mr-1" />
                  Export
                </Button>
                <Button
                  onClick={clearConversation}
                  variant="outline"
                  size="sm"
                  className="h-6 px-2 text-xs"
                >
                  Clear
                </Button>
              </div>
            </div>
            
            <div className="space-y-3 max-h-60 overflow-y-auto">
              {conversation.map((msg, index) => (
                <div key={index} className={`p-3 rounded-lg ${
                  msg.role === 'user' 
                    ? 'bg-purple-900/20 border border-purple-700/30 ml-8' 
                    : 'bg-muted border border-border mr-8'
                }`}>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-medium text-muted-foreground">
                      {msg.role === 'user' ? 'You' : 'AI Assistant'}
                    </span>
                    <Button
                      onClick={() => copyToClipboard(msg.content)}
                      variant="ghost"
                      size="sm"
                      className="h-4 w-4 p-0 ml-auto"
                    >
                      <Copy className="h-3 w-3" />
                    </Button>
                  </div>
                  <div className="text-sm text-foreground whitespace-pre-wrap">
                    {msg.content}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Current Response */}
        {response && conversation.length === 0 && (
          <div className="p-4 bg-muted rounded-lg border border-border">
            <div className="flex justify-between items-center mb-2">
              <Label className="text-sm font-medium text-muted-foreground">AI Response</Label>
              <Button
                onClick={() => copyToClipboard(response)}
                variant="outline"
                size="sm"
                className="h-6 px-2 text-xs"
              >
                <Copy className="h-3 w-3 mr-1" />
                Copy
              </Button>
            </div>
            <div className="text-sm text-foreground whitespace-pre-wrap">
              {response}
            </div>
          </div>
        )}

        {/* Input Area */}
        <div className="p-4 bg-card rounded-lg border-border">
          <div className="space-y-3">
            <Textarea
              placeholder="Ask me anything about coding... (e.g., 'Create a React component for a todo list')"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault()
                  handleSend()
                }
              }}
              className="min-h-[100px] bg-input border-border text-foreground placeholder-muted-foreground"
            />
            
            <div className="flex gap-3">
              <Button
                onClick={handleSend}
                disabled={isLoading || !prompt.trim()}
                className="flex-1 bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 text-white font-medium"
              >
                {isLoading ? (
                  <>
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                    Thinking...
                  </>
                ) : (
                  <>
                    <Send className="h-4 w-4 mr-2" />
                    Send
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Tips */}
      <div className="p-4 bg-card rounded-lg border-border">
        <Label className="text-sm font-medium text-muted-foreground mb-3 block">Tips</Label>
        <ul className="space-y-2 text-xs text-muted-foreground">
          <li className="flex items-start gap-2">
            <span className="text-purple-400">•</span>
            <span>Be specific in your requests for better results</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-purple-400">•</span>
            <span>Include code examples when asking for debugging help</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-purple-400">•</span>
            <span>Use the conversation history to build on previous responses</span>
          </li>
        </ul>
      </div>
    </div>
  )
}

// Image Compressor
function ImageCompressorTool() {
  const [selectedFiles, setSelectedFiles] = useState<File[]>([])
  const [originalImages, setOriginalImages] = useState<Array<{file: File, url: string, size: number}>>([])
  const [compressedImages, setCompressedImages] = useState<Array<{file: File, url: string, size: number, originalSize: number, compressionRatio: string}>>([])
  const [quality, setQuality] = useState(80)
  const [outputFormat, setOutputFormat] = useState('original')
  const [isCompressing, setIsCompressing] = useState(false)
  const [dragActive, setDragActive] = useState(false)
  const [debugMode, setDebugMode] = useState(false)
  
  const handleFiles = (files: FileList | null) => {
    if (!files) return
    
    const newFiles = Array.from(files).filter(file => {
      if (!file.type.startsWith('image/')) {
        toast.error(`${file.name} is not an image file`)
        return false
      }
      if (file.size > 10 * 1024 * 1024) {
        toast.error(`${file.name} is larger than 10MB`)
        return false
      }
      return true
    })
    
    if (newFiles.length === 0) {
      toast.error('No valid image files found')
      return
    }
    
    setSelectedFiles(prev => [...prev, ...newFiles])
    
    // Process each file
    newFiles.forEach((file, index) => {
      const reader = new FileReader()
      reader.onload = (e) => {
        const url = e.target?.result as string
        console.log('File loaded:', file.name, 'URL length:', url.length)
        
        // Verify the data URL is valid
        if (url && url.startsWith('data:image/')) {
          setOriginalImages(prev => [...prev, { file, url, size: file.size }])
        } else {
          console.error('Invalid data URL generated for:', file.name)
          toast.error(`Failed to process ${file.name}`)
        }
      }
      
      reader.onerror = (error) => {
        console.error('FileReader error for', file.name, error)
        toast.error(`Failed to read ${file.name}`)
      }
      
      reader.readAsDataURL(file)
    })
    
    toast.success(`Added ${newFiles.length} image(s)`)
  }
  
  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    handleFiles(event.target.files)
  }
  
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }
  
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFiles(e.dataTransfer.files)
    }
  }
  
  const removeImage = (index: number) => {
    setSelectedFiles(prev => prev.filter((_, i) => i !== index))
    setOriginalImages(prev => prev.filter((_, i) => i !== index))
    setCompressedImages(prev => prev.filter((_, i) => i !== index))
  }
  
  const clearAll = () => {
    setSelectedFiles([])
    setOriginalImages([])
    setCompressedImages([])
  }
  
  const getMimeType = (originalType: string) => {
    if (outputFormat === 'original') return originalType
    if (outputFormat === 'jpeg') return 'image/jpeg'
    if (outputFormat === 'png') return 'image/png'
    if (outputFormat === 'webp') {
      // Check if WebP is supported
      const canvas = document.createElement('canvas')
      canvas.width = 1
      canvas.height = 1
      const webpSupported = canvas.toDataURL('image/webp').indexOf('data:image/webp') === 0
      if (webpSupported) {
        return 'image/webp'
      } else {
        console.warn('WebP not supported, falling back to JPEG')
        toast.info('WebP not supported in this browser, using JPEG instead')
        return 'image/jpeg'
      }
    }
    return originalType
  }
  
  const getFileExtension = (originalName: string, mimeType: string) => {
    if (outputFormat === 'original') {
      return originalName.split('.').pop()
    }
    if (outputFormat === 'jpeg') return 'jpg'
    if (outputFormat === 'png') return 'png'
    if (outputFormat === 'webp') return 'webp'
    return originalName.split('.').pop()
  }
  
  const compressImages = async () => {
    if (originalImages.length === 0) {
      toast.error('No images to compress')
      return
    }
    
    setIsCompressing(true)
    const compressed = []
    
    for (const original of originalImages) {
      try {
        console.log('Compressing image:', original.file.name, 'Type:', original.file.type, 'Size:', original.size)
        
        const result = await new Promise<{url: string, size: number, compressionRatio: string}>((resolve, reject) => {
          const img = new Image()
          
          // Set crossOrigin for potential CORS issues
          img.crossOrigin = 'anonymous'
          
          img.onload = () => {
            try {
              console.log('Image loaded successfully:', img.width, 'x', img.height)
              
              const canvas = document.createElement('canvas')
              const ctx = canvas.getContext('2d')
              
              if (!ctx) {
                reject(new Error('Failed to get canvas context'))
                return
              }
              
              // Set canvas dimensions
              canvas.width = img.width
              canvas.height = img.height
              
              // Clear canvas and draw image
              ctx.clearRect(0, 0, canvas.width, canvas.height)
              ctx.drawImage(img, 0, 0)
              
              const mimeType = getMimeType(original.file.type)
              const qualityValue = mimeType === 'image/png' ? 1 : quality / 100
              
              console.log('Converting to:', mimeType, 'Quality:', qualityValue)
              
              canvas.toBlob(
                (blob) => {
                  if (blob) {
                    console.log('Compression successful. Original size:', original.size, 'Compressed size:', blob.size)
                    
                    const compressedDataUrl = URL.createObjectURL(blob)
                    const compressionRatio = ((1 - blob.size / original.size) * 100).toFixed(1)
                    
                    resolve({
                      url: compressedDataUrl,
                      size: blob.size,
                      compressionRatio
                    })
                  } else {
                    console.error('Canvas toBlob failed')
                    reject(new Error('Failed to compress image - blob is null'))
                  }
                },
                mimeType,
                qualityValue
              )
            } catch (error) {
              console.error('Error during canvas processing:', error)
              reject(error)
            }
          }
          
          img.onerror = (error) => {
            console.error('Image load error:', error)
            reject(new Error(`Failed to load image: ${original.file.name}`))
          }
          
          // Start loading the image
          img.src = original.url
        })
        
        compressed.push({
          file: original.file,
          ...result,
          originalSize: original.size
        })
        
      } catch (error) {
        console.error('Failed to compress:', original.file.name, error)
        const errorMessage = error instanceof Error ? error.message : 'Unknown error'
        toast.error(`Failed to compress ${original.file.name}: ${errorMessage}`)
      }
    }
    
    setCompressedImages(compressed)
    setIsCompressing(false)
    
    if (compressed.length > 0) {
      const avgCompression = (compressed.reduce((sum, img) => sum + parseFloat(img.compressionRatio), 0) / compressed.length).toFixed(1)
      toast.success(`Compressed ${compressed.length} image(s)! Average compression: ${avgCompression}%`)
    } else {
      toast.error('No images were successfully compressed')
    }
  }
  
  const downloadImage = (compressedImage: typeof compressedImages[0]) => {
    const link = document.createElement('a')
    link.href = compressedImage.url
    const extension = getFileExtension(compressedImage.file.name, getMimeType(compressedImage.file.type))
    const baseName = compressedImage.file.name.replace(/\.[^/.]+$/, "")
    link.download = `${baseName}_compressed.${extension}`
    link.click()
    toast.success('Image downloaded!')
  }
  
  const downloadAll = async () => {
    if (compressedImages.length === 0) return
    
    if (compressedImages.length === 1) {
      downloadImage(compressedImages[0])
      return
    }
    
    // For multiple images, download them one by one (simplified approach)
    toast.success(`Downloading ${compressedImages.length} images...`)
    compressedImages.forEach((compressedImage, index) => {
      setTimeout(() => {
        downloadImage(compressedImage)
      }, index * 200) // Small delay between downloads
    })
  }
  
  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB', 'GB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }
  
  return (
    <div className="space-y-6">
      {/* Compression Settings */}
      <div className="p-4 bg-card rounded-lg border-border">
        <Label className="text-sm font-medium text-muted-foreground mb-4 block">Compression Settings</Label>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Quality Slider */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-sm font-medium">Quality: {quality}%</Label>
              <span className="text-xs text-muted-foreground">Lower quality = smaller file size</span>
            </div>
            <Input
              type="range"
              min="10"
              max="100"
              value={quality}
              onChange={(e) => setQuality(parseInt(e.target.value))}
              className="w-full accent-purple-500"
            />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>10% (Max compression)</span>
              <span>100% (Best quality)</span>
            </div>
          </div>
          
          {/* Output Format */}
          <div className="space-y-3">
            <Label className="text-sm font-medium">Output Format</Label>
            <Select value={outputFormat} onValueChange={setOutputFormat}>
              <SelectTrigger className="w-full bg-input border-border text-foreground">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-popover border-border">
                <SelectItem value="original" className="text-foreground">Keep Original Format</SelectItem>
                <SelectItem value="jpeg" className="text-foreground">JPEG (Best for photos)</SelectItem>
                <SelectItem value="png" className="text-foreground">PNG (Best for graphics)</SelectItem>
                <SelectItem value="webp" className="text-foreground">WebP (Modern format)</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground">
              {outputFormat === 'webp' && 'WebP provides best compression with good quality'}
              {outputFormat === 'jpeg' && 'JPEG is ideal for photographs and complex images'}
              {outputFormat === 'png' && 'PNG is best for graphics with transparency'}
              {outputFormat === 'original' && 'Maintain the original file format'}
            </p>
          </div>
        </div>
      </div>
      
      {/* File Upload Area */}
      <div className="p-6 bg-card rounded-lg border-border">
        <Label className="text-sm font-medium text-muted-foreground mb-4 block">Select Images</Label>
        <div
          className={`flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-lg cursor-pointer transition-colors ${
            dragActive 
              ? 'border-purple-500 bg-purple-500/10' 
              : 'border-border bg-card hover:bg-muted'
          }`}
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
        >
          <label className="flex flex-col items-center justify-center w-full h-full cursor-pointer">
            <div className="flex flex-col items-center justify-center pt-5 pb-6">
              <Upload className="w-8 h-8 mb-3 text-muted-foreground" />
              <p className="mb-2 text-sm text-muted-foreground">
                <span className="font-semibold">Click to upload</span> or drag and drop
              </p>
              <p className="text-xs text-muted-foreground">PNG, JPG, GIF, WebP up to 10MB each</p>
            </div>
            <input
              type="file"
              className="hidden"
              accept="image/*"
              multiple
              onChange={handleFileSelect}
            />
          </label>
        </div>
      </div>
      
      {/* Image List with Previews */}
      {selectedFiles.length > 0 && (
        <div className="p-4 bg-card rounded-lg border-border">
          <div className="flex items-center justify-between mb-4">
            <Label className="text-sm font-medium text-muted-foreground">
              Images ({selectedFiles.length})
            </Label>
            <Button
              onClick={clearAll}
              variant="outline"
              size="sm"
              className="bg-secondary border-border text-secondary-foreground hover:bg-muted"
            >
              Clear All
            </Button>
          </div>
          
          <div className="space-y-4 max-h-80 overflow-y-auto">
            {selectedFiles.map((file, index) => {
              const originalImage = originalImages[index]
              const compressedImage = compressedImages[index]
              
              return (
                <div key={index} className="p-4 bg-muted rounded-lg border border-border">
                  <div className="flex items-start gap-4">
                    {/* Preview Thumbnail */}
                    <div className="flex-shrink-0 w-20 h-20 bg-card rounded-lg overflow-hidden border border-border">
                      {originalImage ? (
                        <img
                          src={originalImage.url}
                          alt={`Preview of ${file.name}`}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <ImageIcon className="w-6 h-6 text-muted-foreground" />
                        </div>
                      )}
                    </div>
                    
                    {/* File Info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="text-sm font-medium text-foreground truncate max-w-[200px]">
                          {file.name}
                        </h4>
                        <Button
                          onClick={() => removeImage(index)}
                          variant="ghost"
                          size="sm"
                          className="text-red-400 hover:text-red-300 hover:bg-red-400/10 h-6 w-6 p-0"
                        >
                          ×
                        </Button>
                      </div>
                      
                      <div className="flex items-center gap-4 text-xs text-muted-foreground mb-2">
                        <span>Original: {formatFileSize(file.size)}</span>
                        {compressedImage && (
                          <>
                            <span>Compressed: {formatFileSize(compressedImage.size)}</span>
                            <span className="text-green-400">-{compressedImage.compressionRatio}%</span>
                          </>
                        )}
                      </div>
                      
                      {/* Compression Status */}
                      <div className="flex items-center gap-2">
                        {compressedImage ? (
                          <div className="flex items-center gap-1 text-xs text-green-400">
                            <Check className="w-3 h-3" />
                            <span>Compressed</span>
                          </div>
                        ) : isCompressing ? (
                          <div className="flex items-center gap-1 text-xs text-yellow-400">
                            <RefreshCw className="w-3 h-3 animate-spin" />
                            <span>Processing...</span>
                          </div>
                        ) : (
                          <div className="flex items-center gap-1 text-xs text-muted-foreground">
                            <span>Ready to compress</span>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    {/* Download Button */}
                    {compressedImage && (
                      <Button
                        onClick={() => downloadImage(compressedImage)}
                        variant="outline"
                        size="sm"
                        className="bg-secondary border-border text-secondary-foreground hover:bg-muted h-8"
                      >
                        <Download className="h-3 w-3 mr-1" />
                        Download
                      </Button>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
          
          <div className="flex gap-3 mt-4">
            <Button
              onClick={compressImages}
              disabled={isCompressing || selectedFiles.length === 0}
              className="flex-1 bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 text-white font-medium py-3"
            >
              {isCompressing ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Compressing...
                </>
              ) : (
                <>
                  <ImageIcon className="h-4 w-4 mr-2" />
                  Compress {selectedFiles.length} Image{selectedFiles.length > 1 ? 's' : ''}
                </>
              )}
            </Button>
          </div>
        </div>
      )}
      
      {/* Results with Side-by-Side Comparison */}
      {compressedImages.length > 0 && (
        <div className="space-y-4">
          <div className="p-4 bg-gradient-to-r from-green-900/30 to-emerald-900/30 rounded-lg border border-green-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-green-300">Compression Complete!</p>
                <p className="text-xs text-muted-foreground">
                  Successfully compressed {compressedImages.length} image(s)
                </p>
              </div>
              <Button
                onClick={downloadAll}
                className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white"
              >
                <Download className="h-4 w-4 mr-2" />
                Download {compressedImages.length > 1 ? 'All' : ''}
              </Button>
            </div>
          </div>
          
          <div className="space-y-6">
            {compressedImages.map((compressed, index) => {
              const original = originalImages[index]
              return (
                <div key={index} className="p-4 bg-card rounded-lg border-border">
                  <div className="flex items-center justify-between mb-4">
                    <Label className="text-sm font-medium text-muted-foreground truncate max-w-[300px]">
                      {compressed.file.name}
                    </Label>
                    <div className="flex items-center gap-3">
                      <div className="text-right">
                        <span className="text-xs text-muted-foreground">Original: </span>
                        <span className="text-xs text-foreground">{formatFileSize(compressed.originalSize)}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-xs text-muted-foreground">Compressed: </span>
                        <span className="text-xs text-green-400">{formatFileSize(compressed.size)}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-xs text-purple-400 font-medium">-{compressed.compressionRatio}%</span>
                      </div>
                    </div>
                  </div>
                  
                  {/* Side-by-Side Comparison */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    {/* Original Image */}
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-medium text-muted-foreground">Original</span>
                        <span className="text-xs text-muted-foreground">({formatFileSize(compressed.originalSize)})</span>
                      </div>
                      <div className="relative group">
                        <div className="aspect-video bg-muted rounded-lg overflow-hidden border border-border">
                          {original && (
                            <img
                              src={original.url}
                              alt={`Original version of ${compressed.file.name}`}
                              className="w-full h-full object-contain"
                            />
                          )}
                        </div>
                        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/5 transition-colors rounded-lg pointer-events-none" />
                      </div>
                    </div>
                    
                    {/* Compressed Image */}
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-medium text-green-400">Compressed</span>
                        <span className="text-xs text-green-400">({formatFileSize(compressed.size)}, -{compressed.compressionRatio}%)</span>
                      </div>
                      <div className="relative group">
                        <div className="aspect-video bg-muted rounded-lg overflow-hidden border border-green-700/30">
                          <img
                            src={compressed.url}
                            alt={`Compressed version of ${compressed.file.name}`}
                            className="w-full h-full object-contain"
                          />
                        </div>
                        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/5 transition-colors rounded-lg pointer-events-none" />
                      </div>
                    </div>
                  </div>
                  
                  {/* Action Buttons */}
                  <div className="flex gap-3">
                    <Button
                      onClick={() => downloadImage(compressed)}
                      variant="outline"
                      size="sm"
                      className="flex-1 bg-secondary border-border text-secondary-foreground hover:bg-muted"
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Download Compressed
                    </Button>
                    <Button
                      onClick={() => {
                        // Create a comparison view modal or open in new tab
                        const originalWindow = window.open(original?.url, '_blank')
                        const compressedWindow = window.open(compressed.url, '_blank')
                      }}
                      variant="outline"
                      size="sm"
                      className="bg-secondary border-border text-secondary-foreground hover:bg-muted"
                    >
                      <Eye className="h-4 w-4 mr-2" />
                      Compare
                    </Button>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}
      
      {/* Tips */}
      <div className="p-4 bg-card rounded-lg border-border">
        <Label className="text-sm font-medium text-muted-foreground mb-3 block">Compression Tips</Label>
        <ul className="space-y-2 text-xs text-muted-foreground">
          <li className="flex items-start gap-2">
            <span className="text-purple-400">•</span>
            <span>Use 70-80% quality for good balance between size and quality</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-purple-400">•</span>
            <span>WebP format provides best compression with modern browser support</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-purple-400">•</span>
            <span>JPEG is best for photographs, PNG for graphics with transparency</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-purple-400">•</span>
            <span>Bulk processing saves time when optimizing multiple images</span>
          </li>
        </ul>
      </div>
      
      {/* Debug Panel */}
      {debugMode && (
        <div className="p-4 bg-yellow-900/20 rounded-lg border border-yellow-700">
          <div className="flex items-center justify-between mb-3">
            <Label className="text-sm font-medium text-yellow-300">Debug Information</Label>
            <Button
              onClick={() => setDebugMode(false)}
              variant="ghost"
              size="sm"
              className="text-yellow-400 hover:text-yellow-300 h-6 w-6 p-0"
            >
              ×
            </Button>
          </div>
          <div className="space-y-2 text-xs text-yellow-200 font-mono">
            <div>Selected Files: {selectedFiles.length}</div>
            <div>Original Images: {originalImages.length}</div>
            <div>Compressed Images: {compressedImages.length}</div>
            <div>Quality: {quality}%</div>
            <div>Output Format: {outputFormat}</div>
            <div>Is Compressing: {isCompressing ? 'Yes' : 'No'}</div>
            
            {selectedFiles.length > 0 && (
              <div className="mt-3 pt-3 border-t border-yellow-700">
                <div className="font-medium mb-2">Files:</div>
                {selectedFiles.map((file, index) => (
                  <div key={index} className="ml-2">
                    {file.name} ({formatFileSize(file.size)}) - {file.type}
                  </div>
                ))}
              </div>
            )}
            
            {originalImages.length > 0 && (
              <div className="mt-3 pt-3 border-t border-yellow-700">
                <div className="font-medium mb-2">Original Images:</div>
                {originalImages.map((img, index) => (
                  <div key={index} className="ml-2">
                    {img.file.name} - URL: {img.url.substring(0, 50)}...
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
      
      {/* Debug Toggle */}
      <div className="flex justify-center">
        <Button
          onClick={() => setDebugMode(!debugMode)}
          variant="ghost"
          size="sm"
          className="text-xs text-muted-foreground hover:text-foreground"
        >
          {debugMode ? 'Hide' : 'Show'} Debug Info
        </Button>
      </div>
    </div>
  )
}

// Code Beautifier
function CodeBeautifierTool() {
  const [input, setInput] = useState('')
  const [output, setOutput] = useState('')
  const [language, setLanguage] = useState('javascript')
  
  const beautify = () => {
    try {
      let beautified = input
      
      if (language === 'json') {
        const parsed = JSON.parse(input)
        beautified = JSON.stringify(parsed, null, 2)
      } else if (language === 'javascript' || language === 'typescript') {
        beautified = input
          .replace(/;/g, ';\n')
          .replace(/{/g, ' {\n  ')
          .replace(/}/g, '\n}')
          .replace(/\n\s*\n/g, '\n')
          .split('\n')
          .map((line, index, array) => {
            const trimmed = line.trim()
            if (!trimmed) return ''
            
            let indent = 0
            if (trimmed.includes('}')) {
              indent = Math.max(0, (line.match(/^\s*/)?.[0]?.length || 0) - 2)
            } else {
              indent = line.match(/^\s*/)?.[0]?.length || 0
            }
            
            return ' '.repeat(indent) + trimmed
          })
          .join('\n')
      } else if (language === 'html') {
        beautified = input
          .replace(/></g, '>\n<')
          .split('\n')
          .map((line, index, array) => {
            const trimmed = line.trim()
            if (!trimmed) return ''
            
            let indent = 0
            if (trimmed.includes('</')) {
              indent = Math.max(0, (line.match(/^\s*/)?.[0]?.length || 0) - 2)
            } else if (trimmed.includes('<') && !trimmed.includes('</')) {
              indent = line.match(/^\s*/)?.[0]?.length || 0
            }
            
            return ' '.repeat(indent) + trimmed
          })
          .join('\n')
      } else if (language === 'css') {
        beautified = input
          .replace(/{/g, ' {\n  ')
          .replace(/}/g, '\n}\n')
          .replace(/;/g, ';\n  ')
          .replace(/\n\s*\n/g, '\n')
          .trim()
      }
      
      setOutput(beautified)
      toast.success('Code beautified!')
    } catch (error) {
      toast.error('Failed to beautify code')
    }
  }
  
  return (
    <div className="space-y-6">
      <Select value={language} onValueChange={setLanguage}>
        <SelectTrigger className="w-full">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="javascript">JavaScript</SelectItem>
          <SelectItem value="typescript">TypeScript</SelectItem>
          <SelectItem value="html">HTML</SelectItem>
          <SelectItem value="css">CSS</SelectItem>
          <SelectItem value="json">JSON</SelectItem>
        </SelectContent>
      </Select>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="input" className="text-sm font-medium">Input Code</Label>
          <Textarea
            id="input"
            placeholder={`Enter your ${language} code...`}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            className="min-h-[250px] font-mono text-sm border-2 focus:border-blue-400"
          />
        </div>
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <Label htmlFor="output" className="text-sm font-medium">Beautified Code</Label>
            {output && <CopyButton text={output} />}
          </div>
          <Textarea
            id="output"
            placeholder="Beautified code will appear here..."
            value={output}
            readOnly
            className="min-h-[250px] font-mono text-sm border-2 bg-gray-50"
          />
        </div>
      </div>
      
      <Button onClick={beautify} className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-medium py-3">
        <Sparkles className="h-4 w-4 mr-2" />
        Beautify Code
      </Button>
    </div>
  )
}

export default function Home() {
  const [activeTool, setActiveTool] = useState<string | null>(null)
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('All')
  const [favorites, setFavorites] = useState<string[]>([])
  
  const tools = [
    { id: 'minifier', name: 'PX to REM Converter', category: 'CSS Tools', icon: <Minimize2 className="h-5 w-5" />, component: PxToRemTool, description: 'Convert pixel values to REM units' },
    { id: 'clamp', name: 'Clamp() Generator', category: 'CSS Tools', icon: <Calculator className="h-5 w-5" />, component: ClampCalculatorTool, description: 'Generate fluid typography with CSS clamp() function in REM units' },
    { id: 'svg-optimizer', name: 'SVG Optimizer', category: 'Design Tools', icon: <Minimize2 className="h-5 w-5" />, component: SVGOptimizerTool, description: 'Compress and optimize SVG files' },
    { id: 'svg-viewer', name: 'SVG Code Viewer', category: 'Design Tools', icon: <Code className="h-5 w-5" />, component: SVGCodeViewerTool, description: 'View and edit SVG code with live preview' },
    { id: 'ai-assistant', name: 'AI Coding Assistant', category: 'AI Assistant', icon: <Zap className="h-5 w-5" />, component: AICodingAssistantTool, description: 'Get AI help with coding tasks' },
    { id: 'json', name: 'JSON Formatter', category: 'Code Tools', icon: <FileJson className="h-5 w-5" />, component: JSONFormatterTool, description: 'Format and beautify JSON data' },
    { id: 'base64', name: 'Base64', category: 'Encoders', icon: <Lock className="h-5 w-5" />, component: Base64Tool, description: 'Encode and decode Base64 strings' },
    { id: 'url', name: 'URL Encoder', category: 'Encoders', icon: <LinkIcon className="h-5 w-5" />, component: URLTool, description: 'Encode and decode URLs' },
    { id: 'color', name: 'Color Palette', category: 'Design Tools', icon: <Palette className="h-5 w-5" />, component: ColorPaletteTool, description: 'Generate color palettes' },
    { id: 'lorem', name: 'Lorem Ipsum', category: 'Text Tools', icon: <Type className="h-5 w-5" />, component: LoremIpsumTool, description: 'Generate placeholder text' },
    { id: 'qr', name: 'QR Code', category: 'Generators', icon: <QrCode className="h-5 w-5" />, component: QRCodeTool, description: 'Generate QR codes' },
    { id: 'password', name: 'Password', category: 'Generators', icon: <Key className="h-5 w-5" />, component: PasswordGeneratorTool, description: 'Generate secure passwords' },
    { id: 'markdown', name: 'Markdown', category: 'Text Tools', icon: <FileText className="h-5 w-5" />, component: MarkdownTool, description: 'Preview markdown text' },
    { id: 'regex', name: 'Regex Tester', category: 'Code Tools', icon: <GitBranch className="h-5 w-5" />, component: RegexTool, description: 'Test regular expressions' },
    { id: 'timestamp', name: 'Timestamp', category: 'Converters', icon: <Clock className="h-5 w-5" />, component: TimestampTool, description: 'Convert timestamps' },
    { id: 'css', name: 'CSS Units', category: 'Converters', icon: <Ruler className="h-5 w-5" />, component: CSSUnitTool, description: 'Convert CSS units' },
    { id: 'counter', name: 'Character Counter', category: 'Text Tools', icon: <Calculator className="h-5 w-5" />, component: CharacterCounterTool, description: 'Count characters and words' },
    { id: 'hash', name: 'Hash Generator', category: 'Generators', icon: <Hash className="h-5 w-5" />, component: HashGeneratorTool, description: 'Generate hash values' },
    { id: 'uuid', name: 'UUID Generator', category: 'Generators', icon: <Fingerprint className="h-5 w-5" />, component: UUIDGeneratorTool, description: 'Generate UUIDs' },
    { id: 'image', name: 'Image Compressor', category: 'Design Tools', icon: <ImageIcon className="h-5 w-5" />, component: ImageCompressorTool, description: 'Compress and optimize images' },
    { id: 'beautifier', name: 'Code Beautifier', category: 'Code Tools', icon: <Sparkles className="h-5 w-5" />, component: CodeBeautifierTool, description: 'Beautify code formatting' }
  ]
  
  const categories = ['All', 'Favorites', 'Code Tools', 'Encoders', 'Design Tools', 'Text Tools', 'Generators', 'Converters', 'CSS Tools', 'AI Assistant']
  
  const toggleFavorite = (toolId: string) => {
    setFavorites(prev => 
      prev.includes(toolId) 
        ? prev.filter(id => id !== toolId)
        : [...prev, toolId]
    )
    toast.success(favorites.includes(toolId) ? 'Removed from favorites' : 'Added to favorites')
  }
  
  const filteredTools = useMemo(() => {
    let filtered = tools.filter(tool => {
      const matchesSearch = tool.name.toLowerCase().includes(searchTerm.toLowerCase())
      let matchesCategory = selectedCategory === 'All'
      
      if (selectedCategory === 'Favorites') {
        matchesCategory = favorites.includes(tool.id)
      } else {
        matchesCategory = selectedCategory === 'All' || tool.category === selectedCategory
      }
      
      return matchesSearch && matchesCategory
    })
    
    // Sort favorites to the top
    return filtered.sort((a, b) => {
      const aFav = favorites.includes(a.id)
      const bFav = favorites.includes(b.id)
      if (aFav && !bFav) return -1
      if (!aFav && bFav) return 1
      return 0
    })
  }, [searchTerm, selectedCategory, favorites])
  
  const ActiveComponent = tools.find(t => t.id === activeTool)?.component || null
  const activeToolData = tools.find(t => t.id === activeTool)
  
  return (
    <div className="min-h-screen bg-background">
      <header className="bg-card shadow-lg border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-8">
            <div className="flex-1 text-center">
              <div className="flex justify-center items-center gap-3 mb-4">
                <DevlyLogo size="xl" className="hidden md:block" />
                <DevlyLogo size="lg" className="md:hidden" />
              </div>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Fast, modern utilities for your daily development workflow
              </p>
            </div>
            <div className="flex items-center gap-4">
              <Badge variant="secondary" className="text-sm px-3 py-1">
                {filteredTools.length} Tools
              </Badge>
              <ThemeToggle />
            </div>
          </div>
          
          <div className="flex flex-col gap-4 pb-8">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Search tools..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-full border-2 focus:border-purple-400 bg-input text-foreground placeholder-muted-foreground"
              />
            </div>
            <div className="flex gap-2 flex-wrap justify-center">
              {categories.map(category => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category)}
                  className={`${
                    selectedCategory === category 
                      ? "bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700" 
                      : "bg-secondary border-border text-secondary-foreground hover:bg-muted"
                  }`}
                >
                  {category}
                </Button>
              ))}
            </div>
          </div>
        </div>
      </header>
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 bg-card/50 min-h-screen">
        {activeTool && ActiveComponent ? (
          <div>
            <div className="mb-6">
              <Button 
                onClick={() => setActiveTool(null)}
                variant="outline" 
                className="mb-4 bg-secondary border-border text-secondary-foreground hover:bg-muted"
              >
                ← Back to Tools
              </Button>
              <ToolCard
                title={activeToolData?.name || 'Tool'}
                description={activeToolData?.description || 'Select a tool to get started'}
                category={activeToolData?.category || ''}
                icon={activeToolData?.icon || <Code className="h-5 w-5" />}
              >
                <ActiveComponent />
              </ToolCard>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredTools.map((tool, index) => (
              <ToolGridCard
                key={tool.id}
                tool={tool}
                index={index}
                onOpen={() => setActiveTool(tool.id)}
                isFavorite={favorites.includes(tool.id)}
                onToggleFavorite={() => toggleFavorite(tool.id)}
              />
            ))}
          </div>
        )}
        
        {/* About Section */}
        <div className="mt-16 mb-8 text-center">
          <div className="max-w-3xl mx-auto p-6 bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-950/20 dark:to-pink-950/20 rounded-xl border border-purple-200 dark:border-purple-800">
            <h3 className="text-lg font-semibold text-foreground mb-2">About Devly Tools</h3>
            <p className="text-sm text-muted-foreground mb-3">
              A comprehensive collection of professional development utilities designed to streamline your workflow and boost productivity.
            </p>
            <p className="text-xs text-muted-foreground">
              Created and maintained by <span className="font-medium text-foreground">Tabiul Mursalin</span> with passion for modern web development.
            </p>
          </div>
        </div>
      </main>
      
      <footer className="bg-card border-t border-border mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="text-center text-sm text-muted-foreground">
            <div className="flex justify-center items-center gap-2 mb-2">
              <DevlyLogo size="sm" />
            </div>
            <p className="mb-2">© 2024 Devly. Professional utilities for modern development.</p>
            <p className="text-xs mb-3">Built with ❤️ by <span className="font-medium text-foreground">Tabiul Mursalin</span></p>
            <div className="flex justify-center items-center gap-4 text-xs">
              <Link href="/terms-of-use" className="text-purple-600 hover:text-purple-700 underline">
                Terms of Use
              </Link>
              <span className="text-muted-foreground">•</span>
              <Link href="/privacy-policy" className="text-purple-600 hover:text-purple-700 underline">
                Privacy Policy
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}